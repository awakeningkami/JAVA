package LC42;

import java.util.LinkedList;

/* 接雨水
给定 n 个非负整数表示每个宽度为 1 的柱子的高度图，计算按此排列的柱子，下雨之后能接多少雨水。
 */
public class Solution {
    /*
    暴力    时间O(N^2)  空间O(1)
    每个柱子顶部可以储水的高度为：该柱子的左右两侧最大高度的较小者减去此柱子的高度。
     */
    public int trap(int[] height) {
        int res = 0;
        for (int i = 1; i < height.length - 1; i++) {
            int leftMax = 0, rightMax = 0;
            for (int j = 0; j <= i; j++) {
                leftMax = Math.max(leftMax, height[j]);
            }
            for (int j = i; j < height.length; j++) {
                rightMax = Math.max(rightMax, height[j]);
            }
            res += Math.min(leftMax, rightMax) - height[i];
        }
        return res;
    }
    /*
    动态规划    时间O(N) 空间O(N)
    上述暴力法中，对于每个柱子，都需要从两头重新遍历一遍求出左右两侧的最大高度，有很多重复计算的 dp
     */
    public int trap2(int[] height) {
        int n = height.length;
        int[][] dp = new int[n][2];
        // dp[i][0] 表示下标i的柱子左边的最大值
        // dp[i][1] 表示下标i的柱子右边的最大值
        dp[0][0] = height[0];
        dp[n - 1][1] = height[n - 1];
        for (int i = 1; i < n; i++) {
            dp[i][0] = Math.max(dp[i - 1][0], height[i]);
        }
        for (int i = n - 2; i >= 0; i--) {
            dp[i][1] = Math.max(dp[i + 1][1], height[i]);
        }

        int res = 0;
        for (int i = 1; i < height.length - 1; i++) {
            res += Math.min(dp[i][0], dp[i][1]) - height[i];
        }
        return res;
    }
    /*
    单调栈  时间O(N) 空间O(N)
    简单来说就是当前柱子如果小于等于栈顶元素，说明形不成凹槽，则将当前柱子入栈；
    反之若当前柱子大于栈顶元素，说明形成了凹槽，于是将栈中小于当前柱子的元素pop出来，将凹槽的大小累加到结果中。
     */
    public int trap3(int[] height) {
        LinkedList<Integer> stack = new LinkedList<>();
        int res = 0;
        for (int i = 0; i < height.length; i++) {
            while (!stack.isEmpty() && height[i] > height[stack.peek()]) {
                int peekIndex = stack.pop();
                while (!stack.isEmpty() && height[peekIndex] == height[stack.peek()]) {
                    stack.pop();
                }
                if (!stack.isEmpty()) {  // 如果为空的话说明没有形成凹槽
                    // stack.peek()是此次接住的雨水的左边界的位置，右边界是当前的柱体，即i。
                    res += (Math.min(height[i], height[stack.peek()]) - height[peekIndex]) * (i - stack.peek() - 1);
                }
            }
            stack.push(i);
        }
        return res;
    }


}
