package test;

import java.util.LinkedList;

public class LC84 {
    public int largestRectangleArea(int[] heights) {
        int[] temp = new int[heights.length + 2];
        System.arraycopy(heights, 0, temp, 1, heights.length);
        LinkedList<Integer> stack = new LinkedList<>();
        int res = 0;
        for (int i = 0; i < temp.length; i++) {
            while (!stack.isEmpty() && temp[i] < temp[stack.peek()]) {
                int index = stack.pop();
                res = Math.max(res, temp[index] * (i - stack.peek() - 1));
            }
            stack.push(i);
        }
        return res;
    }
}
