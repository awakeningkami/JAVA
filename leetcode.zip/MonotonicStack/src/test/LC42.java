package test;

import java.util.LinkedList;

public class LC42 {
    public int trap(int[] height) {
        LinkedList<Integer> stack = new LinkedList<>();
        int res = 0;
        for (int i = 0; i < height.length; i++) {
            while (!stack.isEmpty() && height[i] > height[stack.peek()]) {
                int temp = stack.pop();
                while (!stack.isEmpty() && height[stack.peek()] == height[temp]) {
                    stack.pop();
                }
                if (!stack.isEmpty()) {
                    res += (Math.min(height[i], height[stack.peek()]) - height[temp]) * (i - stack.peek() - 1);
                }
            }
            stack.push(i);
        }
        return res;
    }
}
