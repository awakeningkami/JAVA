package LC84;

import java.util.Arrays;
import java.util.LinkedList;

/* 柱状图中最大的矩形
给定 n 个非负整数，用来表示柱状图中各个柱子的高度。每个柱子彼此相邻，且宽度为 1 。
求在该柱状图中，能够勾勒出来的矩形的最大面积。
 */
public class Solution {
    /* dp */
    public int largestRectangleArea(int[] heights) {
        int n = heights.length;
        int[][] dp = new int[n][2];
        // dp[i][0] 下标为i的柱子左边第一个小于该柱子的下标
        // dp[i][1] 下标为i的柱子右边第一个小于该柱子的下标
        dp[0][0] = -1;
        for (int i = 1; i < n; i++) {
            // 这里不能用if，因为dp[i-1][0]为下标为i-1的柱子左边第一个小于该柱子的下标，并不能保证也小于i的柱子
            // 所以只能不断向左寻找
            int temp = i - 1;
            while (temp >= 0 && heights[temp] >= heights[i]) {
                temp = dp[temp][0];
            }
            dp[i][0] = temp;
        }

        dp[n - 1][1] = n;
        for (int i = n - 2; i >= 0; i--) {
            int temp = i + 1;
            while (temp < n && heights[temp] >= heights[i]) {
                temp = dp[temp][1];
            }
            dp[i][1] = temp;
        }
        int res = 0;
        for (int i = 0; i < n; i++) {
            res = Math.max(heights[i] * (dp[i][1] - dp[i][0] - 1), res);
        }
        return res;
    }

    /* 单调栈
    接雨水：单调栈从栈底到栈头的顺序应该是从大到小的顺序，因为要找凹槽
    本题：单调栈从栈底到栈头的顺序应该是从小到大的顺序
    API: System.arraycopy(Object src,  int  srcPos,
                                        Object dest, int destPos,
                                        int length)
    * */
    /*
    与接雨水的区别：

        1. 接雨水不用添加哨兵柱子，因为第一个和最后一个没用；但是此题需要添加
        2. 接雨水相同元素都要出栈，因为求得是和；但是此题可以不出栈，因为求得是最大值
     */
    public int largestRectangleArea2(int[] heights) {
        // 这里为了代码简便，在柱体数组的头和尾加了两个高度为 0 的柱体。(因为计算的时候需要right-left计算宽度)
        int[] temp = new int[heights.length + 2];
        System.arraycopy(heights, 0, temp, 1, heights.length);
        LinkedList<Integer> stack = new LinkedList<>();
        int res = 0;
        for (int i = 0; i < temp.length; i++) {
            while (!stack.isEmpty() && temp[i] < temp[stack.peek()]) {
                int index = stack.pop();
                res = Math.max(res, temp[index] * (i - stack.peek() - 1));
            }
            stack.push(i);
        }
        return res;
    }
}
