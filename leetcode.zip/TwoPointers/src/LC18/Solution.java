package LC18;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
LC15三树之和的基础上多一层循环就行
剪枝可以不用，但是去重必须有
 */
public class Solution {
    public List<List<Integer>> fourSum(int[] nums, int target) {
        Arrays.sort(nums);
        List<List<Integer>> res = new ArrayList<>();
        for (int i = 0; i < nums.length - 3; i++) {
//            // 这块的剪枝不行，因为可能整数溢出，真的难顶，还纳闷为啥python可以
//            if (nums[i] + 3 * nums[i + 1] > target) {
//                break;
//            }
//            // 剪枝
//            if (nums[i] + 3 * nums[nums.length - 1] < target) {
//                continue;
//            }

            // 剪枝 + 去重
            if (i > 0 && nums[i] == nums[i - 1]) {
                continue;
            }
            for (int j = i + 1; j < nums.length - 2; j++) {
//                // 剪枝
//                if (nums[i] + nums[j] + 2 * nums[j + 1] > target) {
//                    break;
//                }
//                // 剪枝
//                if (nums[i] + nums[j] + 2 * nums[nums.length - 1] < target) {
//                    continue;
//                }

                // 剪枝 + 去重
                if (j > i + 1 && nums[j] == nums[j - 1]) {
                    continue;
                }
                int left = j + 1;
                int right = nums.length - 1;
                while (left < right) {
                    int temp = nums[i] + nums[j] + nums[left] + nums[right];
                    if (temp < target) {
                        left++;
                        // 剪枝
                        while (left < right && nums[left] == nums[left - 1]) {
                            left++;
                        }
                    } else if (temp > target) {
                        right--;
                        // 剪枝
                        while (left < right && nums[right] == nums[right + 1]) {
                            right--;
                        }
                    } else {
                        res.add(new ArrayList<>(Arrays.asList(nums[i], nums[j], nums[left], nums[right])));
                        left++;
                        right--;
                        // 去重+剪枝
                        while (left < right && nums[left] == nums[left - 1]) {
                            left++;
                        }
                        // 剪枝，去重在left做了
                        while (left < right && nums[right] == nums[right + 1]) {
                            right--;
                        }

                    }
                }
            }
        }
        return res;
    }

    public static void main(String[] args) {
        int[] nums = new int[]{0,0,0,1000000000,1000000000,1000000000,1000000000};
        Solution solution = new Solution();
        List<List<Integer>> lists = solution.fourSum(nums, 1000000000);
        System.out.println(lists);
    }
}

