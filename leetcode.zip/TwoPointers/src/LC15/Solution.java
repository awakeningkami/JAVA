package LC15;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Solution {
    public List<List<Integer>> threeSum(int[] nums) {
        List<List<Integer>> res = new ArrayList<>();
        Arrays.sort(nums);
        for (int i = 0; i < nums.length; i++) {
            // 剪枝：排序之后如果第一个元素已经大于零，那么无论如何组合都不可能凑成三元组，直接返回结果就可以了
            if (nums[i] > 0) {
                return res;
            }

            if (i > 0 && nums[i] == nums[i - 1]) {  // 去重+剪枝
                continue;
            }
            int left = i + 1;
            int right = nums.length - 1;
            while (left < right) {
                int temp = nums[i] + nums[left] + nums[right];
                if (temp < 0) {
                    left++;
                    while (left < right && nums[left] == nums[left - 1]) {  // 剪枝，去重是在结果中去重的，这里只有剪枝
                        left++;
                    }
                } else if (temp > 0) {
                    right--;
                    while (left < right && nums[right] == nums[right + 1]) {    // 剪枝
                        right--;
                    }
                } else {
                    res.add(new ArrayList<>(Arrays.asList(nums[i], nums[left], nums[right])));
                    left++;
                    right--;
                    while (left < right && nums[left] == nums[left - 1]) {  // 去重+剪枝
                        left++;
                    }
                    while (left < right && nums[right] == nums[right + 1]) {    //  只有剪枝，因为去重在left中做了
                        right--;
                    }
                }
            }

        }
        return res;
    }

    public static void main(String[] args) {
        int[] nums = new int[]{-2, 0, 0, 2, 2};
        Solution solution = new Solution();
        List<List<Integer>> lists = solution.threeSum(nums);
        System.out.println(lists);
    }
}
