package LC206;

/*
给你单链表的头节点 head ，请你反转链表，并返回反转后的链表。
 */
public class Solution {
    // 双指针
    public ListNode reverseList(ListNode head) {
        ListNode left = null;
        ListNode right = head;
        while (right != null) {
            ListNode temp = right.next; // 把下个临时保存，因为要反转了，不保存就找不到了
            right.next = left;
            left = right;
            right = temp;
        }
        return left;
    }
    // 上述的递归版本，但还是从前往后反转
    public ListNode reverseList1(ListNode head) {
        return dfs(null, head);
    }
    private ListNode dfs(ListNode left, ListNode right) {
        if (right == null) {
            return left;
        }
        ListNode temp = right.next;
        right.next = left;
        return dfs(right, temp);
    }


    /*---------------------------------------------------------------*/


    // 递归，从后往前反转
    public ListNode reverseList2(ListNode head) {
        if (head == null) {
            return null;
        }
        return dfs(head);
    }

    private ListNode dfs(ListNode head) {
        if (head.next == null) {    //  递归终止条件，即最后一个节点
            return head;
        }
        ListNode res = dfs(head.next);
        head.next.next = head;
        head.next = null;
        return res;
        /*  以链表1->2->3举例
            递:      (1) head = 1;   res = dfs(2)
                     (2) head = 2;    res = dfs(3)
                     (3) head = 3; return 3
            归：
                     (2) ListNode res = dfs(head.next);  res = 3
                         head.next.next = head;   2.next.next = 2，即 1->2<->3
                         head.next = null;  2.next = null，即 1->2<-3
                         return res;    return 3
                     (1) ListNode res = dfs(head.next);  res = 3
                         head.next.next = head;    1.next.next = 1，即 1<->2<-3
                         head.next = null;  1.next = null，即 null<-1<-2<-3
                         return res;    return 3
                     return res;    return 3
         */

    }
}
