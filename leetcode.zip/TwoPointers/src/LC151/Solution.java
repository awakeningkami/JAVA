package LC151;

/*
给你一个字符串 s ，颠倒字符串中 单词 的顺序。
单词 是由非空格字符组成的字符串。s 中使用至少一个空格将字符串中的 单词 分隔开。
返回 单词 顺序颠倒且 单词 之间用单个空格连接的结果字符串。
注意：输入字符串 s中可能会存在前导空格、尾随空格或者单词间的多个空格。
返回的结果字符串中，单词间应当仅用单个空格分隔，且不包含任何额外的空格。
 */

import java.util.LinkedList;

/*
从后往前遍历一边，找到一个单词的开始（左指针）和结束（右指针）加入到StringBuilder中
 */
public class Solution {
    public String reverseWords(String s) {
        StringBuilder sb = new StringBuilder();
        int right;
        for (int left = s.length() - 1; left >= 0; left--) {
            if (s.charAt(left) == ' ') {   // 跳过空格
                continue;
            }
            right = left;   // right定位到单词的末端
            while (left >= 0 && s.charAt(left) != ' ') {    // left定位到单词的开始
                left--;
            }
            for (int i = left + 1; i <= right; i++) {
                sb.append(s.charAt(i));
            }
            sb.append(' ');
        }
        sb.deleteCharAt(sb.length() - 1);   // 每加一个单词会有一个空格，删除最后的空格
        return sb.toString();
    }

    public static void main(String[] args) {
    }
}
