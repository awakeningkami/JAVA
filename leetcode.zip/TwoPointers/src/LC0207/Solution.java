package LC0207;

import java.util.HashSet;

/*
给你两个单链表的头节点 headA 和 headB ，请你找出并返回两个单链表相交的起始节点。
如果两个链表没有交点，返回 null 。
题目数据 保证 整个链式结构中不存在环。
注意，函数返回结果后，链表必须 保持其原始结构 。
 */
public class Solution {
    // HashSet: O(m + n)  O(m)
    public ListNode getIntersectionNode(ListNode headA, ListNode headB) {
        HashSet<ListNode> set = new HashSet<>();
        ListNode curNode = headA;
        while (curNode != null) {
            set.add(curNode);
            curNode = curNode.next;
        }
        curNode = headB;
        while (curNode != null) {
            if (set.contains(curNode)) {
                return curNode;
            }
            curNode = curNode.next;
        }
        return null;
    }

    // 双指针，因为相交之后就是公共部分，所以先把两个链表的末尾对齐，这样双指针可以同移动
    // O(m + n) O(1)
    public ListNode getIntersectionNode1(ListNode headA, ListNode headB) {
        ListNode curA = headA;
        ListNode curB = headB;
        int lenA = 0, lenB = 0;
        while (curA != null) {
            lenA++;
            curA = curA.next;
        }
        while (curB != null) {
            lenB++;
            curB = curB.next;
        }
        // 让curA为最长链表
        curA = (lenA > lenB) ? headA : headB;
        curB = (lenA > lenB) ? headB : headA;
        int gap = Math.abs(lenA - lenB);
        while (gap-- > 0) { //  对齐
            curA = curA.next;
        }
        while (curA != null) {
            if (curA == curB) {
                return curA;
            }
            curA = curA.next;
            curB = curB.next;
        }
        return null;
    }
}
