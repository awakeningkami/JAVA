package LC142;

/*
给定一个链表的头节点 head，返回链表开始入环的第一个节点。如果链表无环，则返回null。
如果链表中有某个节点，可以通过连续跟踪 next 指针再次到达，则链表中存在环。
为了表示给定链表中的环，评测系统内部使用整数 pos 来表示链表尾连接到链表中的位置（索引从 0 开始）。
如果 pos 是 -1，则在该链表中没有环。注意：pos 不作为参数进行传递，仅仅是为了标识链表的实际情况。
不允许修改 链表。
 */
/*
快慢指针
1. 为何慢指针第一圈走不完一定会和快指针相遇?
设环的长度为 L，当慢指针刚进入环时，慢指针需要走 L 步(即 L 秒)才能走完一圈，此时快指针距离慢指针的最大距离为 L-1，
我们再次以慢指针为参考系，如上所说，快指针在按照1节点/秒的速度在追赶慢指针，所以肯定能在 L 秒内追赶到慢指针。

快指针一次走两个节点，慢指针一次走一个节点：
    假设从头结点到环形入口节点 的节点数为x；
    环形入口节点到 fast指针与slow指针相遇节点 节点数为y；
    从相遇节点 再到环形入口节点节点数为 z；
    那么 x = (n - 1) (y + z) + z，即从头结点出发一个指针，从相遇节点也出发一个指针，
    这两个指针每次只走一个节点，那么当这两个指针相遇的时候就是环形入口的节点。

 */
public class Solution {
    public ListNode detectCycle(ListNode head) {
        ListNode slow = head, fast = head;
        while (fast != null && fast.next != null) { // 因为fast一次走两个节点，会有fast.next.next，所以终止条件这样写
            fast = fast.next.next;
            slow = slow.next;
            if (fast == slow) {
                ListNode ptr = head;
                while (ptr != slow) {
                    ptr = ptr.next;
                    slow = slow.next;
                }
                return ptr;
            }
        }
        return null;
    }
}
