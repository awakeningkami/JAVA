package LC454;

import java.util.HashMap;

/*
给你四个整数数组 nums1、nums2、nums3 和 nums4 ，数组长度都是 n ，
请你计算有多少个元组 (i, j, k, l) 能满足：
0 <= i, j, k, l < n
nums1[i] + nums2[j] + nums3[k] + nums4[l] == 0

 */
public class Solution {
    public int fourSumCount(int[] nums1, int[] nums2, int[] nums3, int[] nums4) {
        HashMap<Integer, Integer> map = new HashMap<>();

        for (int num1 : nums1) {
            for (int num2 : nums2) {
                map.put(num1 + num2, map.getOrDefault(num1 + num2, 0) + 1);
            }
        }
        int res = 0;
        for (int num3 : nums3) {
            for (int num4 : nums4) {
                res += map.getOrDefault(-num3 - num4, 0);
//                if (map.containsKey(-num3 - num4)) {
//                    res += map.get(-num3 - num4);
//                }
            }
        }

        return res;
    }

    public static void main(String[] args) {
        int[] nums1 = new int[]{1, 2};
        int[] nums2 = new int[]{-2, -1};
        int[] nums3 = new int[]{-1, 2};
        int[] nums4 = new int[]{0, 2};
        Solution solution = new Solution();
        solution.fourSumCount(nums1, nums2, nums3, nums4);
    }
}
