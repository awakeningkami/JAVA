package LC15;

/*
给你一个包含 n 个整数的数组 nums，判断 nums 中是否存在三个元素 a，b，c ，
使得 a + b + c = 0 ？请你找出所有和为 0 且不重复的三元组。
注意：答案中不可以包含重复的三元组。
 */

import java.util.*;

/*
a + b = -c，貌似可以使用哈希表记录a+b的值然后去找c，但是去重是一个问题。
而去重问题一般能排序则先排序，方便去重。
常规暴力解法：三重for循环，但是第二重合第三重是有关系的，a+b+c=0，b增大，那么c一定减小。
当需要枚举数组中的两个元素时，如果随着第一个元素的递增，第二个元素是递减的，那么就可以使用双指针的方法。
 */
public class Solution {
    public List<List<Integer>> threeSum(int[] nums) {
        List<List<Integer>> res = new ArrayList<>();
        Arrays.sort(nums);
        for (int i = 0; i < nums.length; i++) {
            // 剪枝：排序之后如果第一个元素已经大于零，那么无论如何组合都不可能凑成三元组，直接返回结果就可以了
            if (nums[i] > 0) {
                return res;
            }

            if (i > 0 && nums[i] == nums[i - 1]) {  // 去重+剪枝
                continue;
            }
            int left = i + 1;
            int right = nums.length - 1;
            while (left < right) {
                int temp = nums[i] + nums[left] + nums[right];
                if (temp < 0) {
                    left++;
                    // 可以不用，因为并没有减少判断
                    while (left < right && nums[left] == nums[left - 1]) {  // 剪枝，去重是在结果中去重的，这里只有剪枝
                        left++;
                    }
                } else if (temp > 0) {
                    right--;
                    while (left < right && nums[right] == nums[right + 1]) {    // 剪枝
                        right--;
                    }
                } else {
                    res.add(new ArrayList<>(Arrays.asList(nums[i], nums[left], nums[right])));
                    left++;
                    right--;
                    while (left < right && nums[left] == nums[left - 1]) {  // 去重+剪枝
                        left++;
                    }
                    while (left < right && nums[right] == nums[right + 1]) {    //  只有剪枝，因为去重在left中做了
                        right--;
                    }
                }
            }

        }
        return res;
    }

    public static void main(String[] args) {
        int[] nums = new int[]{-2, 0, 0, 2, 2};
        Solution solution = new Solution();
        List<List<Integer>> lists = solution.threeSum(nums);
        System.out.println(lists);
    }
}

// 回溯 O(n^4)，当然需要剪枝，不然超时
class Solution2 {
    List<List<Integer>> res = new ArrayList<>();
    List<Integer> path = new ArrayList<>();
    int sum = 0;
    public List<List<Integer>> threeSum(int[] nums) {
        Arrays.sort(nums);
        backtracking(nums, 0, 0);
        return res;
    }
    private void backtracking(int[] nums, int index, int target) {
        if (path.size() == 3) {
            if (sum == target) {
                res.add(new ArrayList<>(path));
            }
            return;
        }
        for (int i = index; i < nums.length; i++) {
            // 树层去重
            if (i > index && nums[i] == nums[i - 1]) {
                continue;
            }
            sum += nums[i];
            path.add(nums[i]);
            backtracking(nums, i + 1, target);
            sum -= nums[i];
            path.remove(path.size() - 1);
        }
    }
}
