package LC15;

import java.util.*;

public class Main {

    public void help(int[] nums) {
        LinkedList<Integer> queue = new LinkedList<>();
        for (int i =nums.length - 1; i >=0; i--) {
            queue.offerFirst(nums[i]);
            queue.offerFirst(queue.pollLast());
            queue.offerFirst(queue.pollLast());
        }
        int size = queue.size();
        for (int i = 0; i < size; i++) {
            System.out.print(queue.poll() + " ");
        }
    }

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[] nums = new int[n];
        for (int i = 0; i < n; i++) {
            nums[i] = scanner.nextInt();
        }
//        int[] nums = new int[]{1,2,3,4};
        Main main = new Main();
        main.help(nums);
    }
}
