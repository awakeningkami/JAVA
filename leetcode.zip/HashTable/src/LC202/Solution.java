package LC202;

/*
编写一个算法来判断一个数 n 是不是快乐数。
「快乐数」 定义为：
对于一个正整数，每一次将该数替换为它每个位置上的数字的平方和。
然后重复这个过程直到这个数变为 1，也可能是 无限循环 但始终变不到 1。
如果这个过程 结果为 1，那么这个数就是快乐数。
如果 n 是 快乐数 就返回 true ；不是，则返回 false 。

输入：n = 19
输出：true
解释：
12 + 92 = 82
82 + 22 = 68
62 + 82 = 100
12 + 02 + 02 = 1
 */

import java.util.HashSet;

/*
根据我们的探索，我们猜测会有以下三种可能。
1. 最终会得到 1。
2. 最终会进入循环。
3. 值会越来越大，最后接近无穷大。
Digits	Largest	                Next
1	        9	                81
2	        99	                162
3	        999	                243
4	        9999	            324
13	        9999999999999	    1053
对于3位数的数字，它不可能大于243。这意味着它要么被困在243以下的循环内，要么跌到1。
4位或4位以上的数字在每一步都会丢失一位，直到降到3位为止。
所以我们知道，最坏的情况下，算法可能会在243以下的所有数字上循环，
然后回到它已经到过的一个循环或者回到1。但它不会无限期地进行下去，所以我们排除第三种选择。
 */


/*
本问题的关键点：
题目中说了会无限循环，那么也就是说求和的过程中，sum会重复出现
当遇到了要快速判断一个元素是否出现集合里的时候，就要考虑哈希法了。
 */
public class Solution {
    HashSet<Integer> set = new HashSet<>();
    public boolean isHappy(int n) {
        String s = String.valueOf(n);
        s.split(" +");
        int sum = 0;
        for (int i = 0; i < s.length(); i++) {
            sum += Math.pow((s.charAt(i) - '0'), 2);
        }
        if (sum == 1) {
            return true;
        }
        if (set.contains(sum)) {
            return false;
        }
        set.add(sum);
        System.out.println(sum);
        return isHappy(sum);
    }

    public static void main(String[] args) {
        Solution solution = new Solution();
        solution.isHappy(19);
        System.out.println();
    }
}
