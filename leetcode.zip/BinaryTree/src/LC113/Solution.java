package LC113;

import java.util.ArrayList;
import java.util.List;

/*
给你二叉树的根节点 root 和一个整数目标和 targetSum ，
找出所有 从根节点到叶子节点 路径总和等于给定目标和的路径。
 */
// see LC112 LC257
public class Solution {
    private List<List<Integer>> res = new ArrayList<>();
    private List<Integer> node = new ArrayList<>();
    public List<List<Integer>> pathSum(TreeNode root, int targetSum) {
        if (root == null) {
            return res;
        }
        dfs(root, targetSum);
        return res;
    }
    private void dfs(TreeNode root, int count) {
        node.add(root.val);
        if (root.left == null && root.right == null && count == root.val) {
            res.add(new ArrayList<>(node));   // 一定要复制，否则res添加的只是node的引用
        }
        if (root.left != null) {
            dfs(root.left, count - root.val);   // 有回溯
            node.remove(node.size() - 1);   // 回溯
        }
        if (root.right != null) {
            dfs(root.right, count - root.val);  // 有回溯
            node.remove(node.size() - 1);   // 回溯
        }
    }
    public static void main(String[] args) {
        TreeNode node1 = new TreeNode(1);
        TreeNode node2 = new TreeNode(2);
        TreeNode node3 = new TreeNode(3);
        node1.left = node2;
        node1.right = node3;
        Solution solution = new Solution();
        solution.pathSum(node1, 3);
    }
}
