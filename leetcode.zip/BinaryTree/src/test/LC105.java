package test;

import java.util.HashMap;

public class LC105 {
    HashMap<Integer, Integer> map = new HashMap<>();
    public TreeNode buildTree(int[] preorder, int[] inorder) {
        for (int i = 0; i < inorder.length; i++) {
            map.put(inorder[i], i);
        }

        return dfs(inorder, 0, inorder.length - 1, preorder, 0, preorder.length - 1);

    }

    private TreeNode dfs(int[] in, int leftInLeft, int rightInRight,
                         int[] pre, int leftPreLeft, int rightPreRight) {
        if (leftInLeft > rightInRight) {
            return null;
        }
        int value = pre[leftPreLeft];
        int index = map.get(value);
        TreeNode root = new TreeNode(value);

        int leftInRight = index - 1;
        int rightInLeft = index + 1;

        int rightPreLeft = rightPreRight - (rightInRight - rightInLeft);
        int leftPreRight = rightPreLeft - 1;

        root.left = dfs(in, leftInLeft, leftInRight, pre, leftPreLeft + 1, leftPreRight);
        root.right = dfs(in, rightInLeft, rightInRight, pre, rightPreLeft, rightPreRight);
        return root;
    }
}
