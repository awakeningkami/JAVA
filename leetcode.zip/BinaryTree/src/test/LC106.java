package test;


import java.util.HashMap;

public class LC106 {
    HashMap<Integer, Integer> map = new HashMap<>();
    public TreeNode buildTree(int[] inorder, int[] postorder) {
        for (int i = 0; i < inorder.length; i++) {
            map.put(inorder[i], i);
        }
        return dfs(inorder, 0, inorder.length - 1,  postorder,0, postorder.length - 1);
    }

    private TreeNode dfs(int[] in, int leftInLeft, int rightInRight,
                        int[] post, int leftPostLeft, int rightPostRight) {
        if (leftInLeft > rightInRight) {
            return null;
        }
        int value = post[rightPostRight];
        int index = map.get(value);
        TreeNode root = new TreeNode(value);

        int leftInRight = index - 1;
        int rightInLeft = index + 1;

        int leftPostRight = leftPostLeft + (leftInRight - leftInLeft);
        int rightPostLeft = leftPostRight + 1;

        root.left = dfs(in, leftInLeft, leftInRight, post, leftPostLeft, leftPostRight);
        root.right = dfs(in, rightInLeft, rightInRight, post, rightPostLeft, rightPostRight - 1);
        return root;
    }
}
