package LC236;

/*
给定一个二叉树, 找到该树中两个指定节点的最近公共祖先。
百度百科中最近公共祖先的定义为：
“对于有根树 T 的两个节点 p、q，最近公共祖先表示为一个节点 x，满足 x 是 p、q 的祖先且 x 的深度尽可能大
（一个节点也可以是它自己的祖先）。”
 */

/*
“那么二叉树如何可以自底向上查找呢？
回溯啊，二叉树回溯的过程就是从低到上。
后序遍历就是天然的回溯过程，最先处理的一定是叶子节点”
二叉树的后续遍历本质上是回溯，自底向上查找
 */
public class Solution {
    public TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
        return postDFS(root, p, q);
    }

    private TreeNode postDFS(TreeNode root, TreeNode p, TreeNode q) {
        /*
        和LC235不同，自下向上需要考虑null
         */
        if (root == null || root == p || root == q) {
            // root == p 返回的原因：如果后面没有查找到q（q只可能在root的子树中），那么此时的root肯定就是最近公共祖先
            // 所以我们先认为root是最近公共祖先，直接返回。root == q同理。
            return root;
        }
        TreeNode left = postDFS(root.left, p, q);
        TreeNode right = postDFS(root.right, p, q);
        if (left == null) { //  左子树没找到p和q，那么就看你右子树找到了谁
            return right;
        } else if (right == null) { //  右子树没找到p和q，那么就看你左子树找到了谁
            return left;
        } else {    // p和q分布在左右子树，此时的root就是最近公共祖先
            return root;
        }
    }
}
