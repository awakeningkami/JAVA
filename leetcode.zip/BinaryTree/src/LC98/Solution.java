package LC98;


import java.util.LinkedList;

/*
给你一个二叉树的根节点 root ，判断其是否是一个有效的二叉搜索树。
 */
// 不能单纯的比较左节点小于中间节点，右节点大于中间节点就完事了。
// 中序遍历，递增即可
public class Solution {
    TreeNode pre;
    public boolean isValidBST(TreeNode root) {
        return dfs(root);
    }
    private boolean dfs(TreeNode root) {
        if (root == null) {
            return true;
        }
        boolean isBst = dfs(root.left);
        if (!isBst) {
            return false;
        }
        if (pre != null && root.val <= pre.val) {   // pre != null, 因为可能pre未赋值
            return false;
        }
        pre = root;
        return dfs(root.right);
    }

    // 迭代
    public boolean isValidBST2(TreeNode root) {
        LinkedList<TreeNode> stack = new LinkedList<>();
        TreeNode pre = null;
        TreeNode cur = root;
        while (cur!= null || !stack.isEmpty()) {
            while (cur != null) {
                stack.push(cur);
                cur = cur.left;
            }
            // 当前节点为空，说明左边走到头了，从栈中弹出节点并保存
            // 然后转向右边节点，继续上面整个过程
            TreeNode node = stack.pop();
            if (pre != null && node.val <= pre.val) {
                return false;
            }
            pre = node;
            cur = node.right;
        }
        return true;
    }
}
