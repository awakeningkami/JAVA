package LC404;

/*
给定二叉树的根节点 root ，返回所有左叶子之和。
 */
// 看清楚了，是左叶子，不是左节点。服了！
// 一个节点为左叶子节点，当且仅当它是某个节点的左子节点，并且它是一个叶子结点。
public class Solution {
    int res = 0;

    public int sumOfLeftLeaves(TreeNode root) {
        dfs(root);
        return res;
    }

    private void dfs(TreeNode root) {
        if (root == null) {
            return;
        }
        if (root.left != null && root.left.left == null && root.left.right == null) {
            res += root.left.val;
        }
        dfs(root.left);
        dfs(root.right);
    }

    // 2
    public int sumOfLeftLeaves2(TreeNode root) {
        if (root == null) {
            return 0;
        }
        if (root.left != null && root.left.left == null && root.left.right == null) {
            return root.left.val + sumOfLeftLeaves2(root.right);
        }
        return sumOfLeftLeaves2(root.left) + sumOfLeftLeaves2(root.right);
    }
}
