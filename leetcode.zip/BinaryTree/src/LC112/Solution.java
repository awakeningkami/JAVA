package LC112;

/*
给你二叉树的根节点 root 和一个表示目标和的整数 targetSum 。
判断该树中是否存在 根节点到叶子节点 的路径，这条路径上所有节点值相加等于目标和 targetSum 。
如果存在，返回 true ；否则，返回 false 。
 */
/*
 注意：是否对数值进行回溯主要是看，递归代码块之前的数值是否被改变，如果"归"后改变了，
 那么一定对数值进行回溯，要不然后续如果有代码对该数值进行操作就有问题（我还没操作，你就变了？）
 */
// see LC257
public class Solution {
    public boolean hasPathSum(TreeNode root, int targetSum) {
        if (root == null) {
            return false;
        }
        return dfs(root, targetSum);
    }

    private boolean dfs(TreeNode root, int count) {
        if (root.left == null && root.right == null) {
            return count == root.val;
        }
        if (root.left != null) {
            boolean left = dfs(root.left, count - root.val);    // 有回溯
            if (left) {   // 找到就提前返回
                return true;
            }
        }
        if (root.right != null) {
            boolean right = dfs(root.right, count - root.val);  // 有回溯
            if (right) {  // 找到就提前返回
                return true;
            }
        }
        return false;
    }
}
