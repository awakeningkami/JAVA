package LC701;

/*
给定二叉搜索树（BST）的根节点 root 和要插入树中的值 value ，将值插入二叉搜索树。
返回插入后二叉搜索树的根节点。 输入数据 保证 ，新值和原始二叉搜索树中的任意节点值都不同。

注意，可能存在多种有效的插入方式，只要树在插入后仍保持为二叉搜索树即可。 你可以返回 任意有效的结果 。

 */
public class Solution {
    public TreeNode insertIntoBST(TreeNode root, int val) {
        return dfs(root, val);
    }
    private TreeNode dfs(TreeNode root, int val) {
        if (root == null) {
            return new TreeNode(val);
        }
        if (root.val > val) {
            root.left = dfs(root.left, val);
        } else {
            root.right = dfs(root.right, val);
        }
        return root;
    }

    // 迭代
    public TreeNode insertIntoBST2(TreeNode root, int val) {
        TreeNode node = new TreeNode(val);
        TreeNode dummy = root;
        TreeNode pre = root;
        if (root == null) {
            return node;
        }
        while (root != null) {
            pre = root;
            if (root.val > val) {
                root = root.left;
            } else {
                root = root.right;
            }
        }
        if (pre.val > val) {
            pre.left = node;
        } else {
            pre.right = node;
        }
        return dummy;
    }
}

// 退化为迭代
class Solution2 {
    TreeNode pre;
    TreeNode dummy;
    public TreeNode insertIntoBST(TreeNode root, int val) {
        pre = dummy = root;
        if (root == null) {
            return new TreeNode(val);
        }
        dfs(root, val);
        return dummy;
    }
    private void dfs(TreeNode root, int val) {
        if (root == null) {
            TreeNode node = new TreeNode(val);
            if (pre.val > val) {
                pre.left = node;
            } else {
                pre.right = node;
            }
            return;
        }
        pre = root;
        if (root.val > val) {
            dfs(root.left, val);
        } else {
            dfs(root.right, val);
        }
    }

}