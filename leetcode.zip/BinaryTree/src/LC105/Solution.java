package LC105;

import java.util.HashMap;

/*
给定两个整数数组 preorder 和 inorder ，其中 preorder 是二叉树的先序遍历，
inorder 是同一棵树的中序遍历，请构造二叉树并返回其根节点。
 */
public class Solution {
    HashMap<Integer, Integer> map = new HashMap<>();
    public TreeNode buildTree(int[] preorder, int[] inorder) {
        for (int i = 0; i < inorder.length; i++) {
            map.put(inorder[i], i);
        }
        return dfs(inorder, 0, inorder.length - 1, preorder, 0, preorder.length - 1);
    }
    private TreeNode dfs(int[] inorder, int inorderLeft, int inorderRight,
                         int[] preorder, int preorderLeft, int preorderRight) {
        if (inorderLeft > inorderRight) {
            return null;
        }
        int delimiterValue = preorder[preorderLeft];
        int delimiterIndex = map.get(delimiterValue);
        TreeNode root = new TreeNode(delimiterValue);
        // 切割，中序数组的左部分（根节点的左子树）
        int leftInorderRight = delimiterIndex - 1;
        // 切割，中序数组的右部分（根节点的右子树）
        int rightInorderLeft = delimiterIndex + 1;

        // 切割，前序数组的右部分（根节点的右子树）
        int rightPreorderLeft = preorderRight - (inorderRight - rightInorderLeft);
        // 切割，前序数组的左部分（根节点的左子树）
        int leftPreorderRight = rightPreorderLeft - 1;

        // 注意去除前序数组的根节点
        root.left = dfs(inorder, inorderLeft, leftInorderRight, preorder, preorderLeft + 1, leftPreorderRight);
        root.right = dfs(inorder, rightInorderLeft, inorderRight, preorder, rightPreorderLeft, preorderRight);
        return root;
    }
}

class Solution2 {
    HashMap<Integer, Integer> map = new HashMap<>();
    public TreeNode buildTree(int[] preorder, int[] inorder) {
        for (int i = 0; i < inorder.length; i++) {
            map.put(inorder[i], i);
        }
        return dfs(inorder, 0, inorder.length - 1, preorder, 0, preorder.length - 1);
    }
    private TreeNode dfs(int[] inorder, int leftInorderLeft, int rightInorderRight,
                         int[] preorder, int leftPreorderLeft, int rightPreorderRight) {
        if (leftInorderLeft > rightInorderRight) {
            return null;
        }
        int delimiterValue = preorder[leftPreorderLeft];
        int delimiterIndex = map.get(delimiterValue);
        TreeNode root = new TreeNode(delimiterValue);
        // 切割，中序数组的左部分（根节点的左子树）
        int leftInorderRight = delimiterIndex - 1;
        // 切割，中序数组的右部分（根节点的右子树）
        int rightInorderLeft = delimiterIndex + 1;

        // 切割，前序数组的右部分（根节点的右子树）
        int rightPreorderLeft = rightPreorderRight - (rightInorderRight - rightInorderLeft);
        // 切割，前序数组的左部分（根节点的左子树）
        int leftPreorderRight = rightPreorderLeft - 1;

        // 注意去除前序数组的根节点
        root.left = dfs(inorder, leftInorderLeft, leftInorderRight, preorder, leftPreorderLeft + 1, leftPreorderRight);
        root.right = dfs(inorder, rightInorderLeft, rightInorderRight, preorder, rightPreorderLeft, rightPreorderRight);
        return root;
    }
}