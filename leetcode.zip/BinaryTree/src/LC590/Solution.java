package LC590;

import java.util.ArrayList;
import java.util.List;

public class Solution {
    public List<Integer> postorder(Node root) {
        List<Integer> res = new ArrayList<>();
        traversal(root, res);
        return res;
    }
    private void traversal(Node root, List<Integer> res) {
        if (root == null) {
            return;
        }
        for (Node n : root.children) {
            traversal(n, res);
        }
        res.add(root.val);
    }
}
