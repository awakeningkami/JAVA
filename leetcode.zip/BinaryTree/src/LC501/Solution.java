package LC501;

import java.util.*;
import java.util.stream.Collectors;

/*
给你一个含重复值的二叉搜索树（BST）的根节点 root ，找出并返回 BST 中的所有 众数。
如果树中有不止一个众数，可以按 任意顺序 返回。

假定 BST 满足如下定义：
结点左子树中所含节点的值 小于等于 当前节点的值
结点右子树中所含节点的值 大于等于 当前节点的值
左子树和右子树都是二叉搜索树
 */
// 二叉搜索树
public class Solution {
    int maxCount;
    int count;
    TreeNode pre;
    ArrayList<Integer> list = new ArrayList<>();

    public int[] findMode(TreeNode root) {
        dfs(root);
        int[] res = new int[list.size()];
        for (int i = 0; i < res.length; i++) {
            res[i] = list.get(i);
        }
        return res;
//        return list.stream().mapToInt(Integer::intValue).toArray();
    }

    private void dfs(TreeNode root) {
        if (root == null) {
            return;
        }
        dfs(root.left);

        if (pre == null) {  // 第一个节点
            count = 1;
        } else if (pre.val == root.val) {   // 与前一个节点数值相同
            count++;
        } else {    // 与前一个节点数值不同
            count = 1;
        }
        if (count > maxCount) {
            list.clear();
            maxCount = count;
            list.add(root.val);
        } else if (count == maxCount) {
            list.add(root.val);
        }
        pre = root;
        dfs(root.right);
    }
}

// 普通二叉树
class Solution2 {
    Map<Integer, Integer> map = new HashMap<>();
    public int[] findMode(TreeNode root) {
        ArrayList<Integer> resList = new ArrayList<>();
        dfs(root);
        // sort
        List<Map.Entry<Integer, Integer>> list = new ArrayList<>(map.entrySet());
        list.sort((o1, o2) -> -Integer.compare(o1.getValue(), o2.getValue()));
        int maxCount = list.get(0).getValue();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getValue() == maxCount) {
                resList.add(list.get(i).getKey());
            }
        }
        // ArrayList to Array
        int[] resArray = new int[resList.size()];
        for (int i = 0; i < resArray.length; i++) {
            resArray[i] = resList.get(i);
        }
        return resArray;
    }

    private void dfs(TreeNode root) {
        if (root == null) {
            return;
        }
        map.put(root.val, map.getOrDefault(root.val, 0) + 1);
//        if (map.containsKey(root.val)) {
//            map.put(root.val, map.get(root.val) + 1);
//        } else {
//            map.put(root.val, 1);
//        }
        dfs(root.left);
        dfs(root.right);
    }
}

