package LC700;

import java.util.LinkedList;

/*
给定二叉搜索树（BST）的根节点 root 和一个整数值 val。
你需要在 BST 中找到节点值等于 val 的节点。
返回以该节点为根的子树。 如果节点不存在，则返回 null 。
 */
public class Solution {
    public TreeNode searchBST(TreeNode root, int val) {
        return dfs(root, val);
    }
    private TreeNode dfs(TreeNode root, int val) {
        if (root == null || root.val == val) {
            return root;
        }
        if (root.val > val) {
            return dfs(root.left, val);
        } else {
            return dfs(root.right, val);
        }
    }
    // 迭代
    public TreeNode searchBST2(TreeNode root, int val) {
        while (root != null) {
            if (root.val == val) {
                return root;
            } else if (root.val > val) {
                root = root.left;
            } else {
                root = root.right;
            }
        }
        return null;
    }
}

// 普通二叉树
class Solution2 {
    public TreeNode searchBST(TreeNode root, int val) {
        return dfs(root, val);
    }
    private TreeNode dfs(TreeNode root, int val) {
        if (root == null || root.val == val) {
            return root;
        }
        TreeNode left = dfs(root.left, val);
        if (left != null) {
            return left;  // 找到就提前返回
        }
        return dfs(root.right, val);
    }
    // 迭代
    public TreeNode searchBST2(TreeNode root, int val) {
        if(root == null || root.val == val) {
            return root;
        }
        LinkedList<TreeNode> stack = new LinkedList<>();
        stack.push(root);
        while (!stack.isEmpty()) {
            TreeNode node = stack.pop();
            if (node.val == val) {
                return node;
            }
            if (node.right != null) {
                stack.push(node.right);
            }
            if (node.left != null) {
                stack.push(node.left);
            }
        }
        return null;
    }
}