package LC513;
/*
给定一个二叉树的 根节点 root，请找出该二叉树的 最底层 最左边 节点的值。
假设二叉树中至少有一个节点。
 */

/*
 求每个叶子的深度是从上往下，这时需要回溯；如果只求树的深度，没必要回溯；
 求树的高度是从下往上，返回值就行；（可能描述的不是很正确，意思懂就行）
 */

import java.util.LinkedList;

public class Solution {
    private int maxDepth = -1;
    private int leftLeaf = 0;
    // dfs
    public int findBottomLeftValue(TreeNode root) {
        dfs(root, 1);
        return leftLeaf;
    }
    private void dfs(TreeNode root, int depth) {
        if (root.left == null && root.right == null) {
            if (depth > maxDepth) {
                maxDepth = depth;
                leftLeaf = root.val;
            }
            return;
        }
//        if (root.left != null) {
//            depth++;  // 深度加一
//            dfs(root.left, depth);
//            depth--;
//        }
//        if (root.right != null) {
//            depth++;  // 深度加一
//            dfs(root.right, depth);
//            depth--;  // 回溯，深度减一
//        }

        // 回溯部分的代码可以简化
        if (root.left != null) {
            dfs(root.left, depth + 1);   // 隐藏着回溯
        }
        if (root.right != null) {
            dfs(root.right, depth + 1);  // 隐藏着回溯
        }
    }

    // bfs
    public int findBottomLeftValue2(TreeNode root) {
        LinkedList<TreeNode> queue = new LinkedList<>();
        int res = 0;
        queue.offer(root);
        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            for (int i = 0; i < levelSize; i++){
                TreeNode node = queue.poll();
                if (i == 0) {
                    res = node.val;
                }
                if (node.left != null) {
                    queue.offer(node.left);
                }
                if (node.right != null) {
                    queue.offer(node.right);
                }
            }
        }
        return res;
    }
}
