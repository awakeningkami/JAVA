package LC106;

import java.util.HashMap;

/*
给定两个整数数组 inorder 和 postorder ，其中 inorder 是二叉树的中序遍历，
postorder 是同一棵树的后序遍历，请你构造并返回这颗 二叉树 。
 */
/*
根据后序最后一个元素，切割中序，得到左右子树；递归解决，每次后序数组最后一个元素就是节点元素。
 */
public class Solution {
    public TreeNode buildTree(int[] inorder, int[] postorder) {
        return dfs(inorder, 0, inorder.length - 1, postorder, 0, postorder.length - 1);
    }
    private TreeNode dfs(int[] inorder, int inorderLeft, int inorderRight,
                         int[] postorder, int postorderLeft, int postorderRight) {
        if (inorderLeft > inorderRight) {
            return null;
        }
        // 切割点
        int delimiterValue = postorder[postorderRight];
        int delimiterIndex = inorderDelimiterIndex(inorder, inorderLeft, inorderRight, delimiterValue);
        TreeNode root = new TreeNode(delimiterValue);

        // 切割，中序数组的左部分（根节点的左子树）
        int leftInorderRight = delimiterIndex - 1;
        // 切割，中序数组的右部分（根节点的右子树）
        int rightInorderLeft = delimiterIndex + 1;

        // 切割，后序数组的左部分（根节点的左子树）
        int leftPostorderRight = postorderLeft + (leftInorderRight - inorderLeft);
        // 切割，后序数组的右部分（根节点的右子树）
        int rightPostorderLeft = leftPostorderRight + 1;

        root.left = dfs(inorder, inorderLeft, leftInorderRight, postorder, postorderLeft, leftPostorderRight);
        // 注意去除后序数组的根节点
        root.right = dfs(inorder, rightInorderLeft, inorderRight, postorder, rightPostorderLeft, postorderRight - 1);
        return root;
    }

    private int inorderDelimiterIndex(int[] inorder, int inorderLeft, int inorderRight, int delimiterValue) {
        int delimiterIndex;
        for (delimiterIndex = inorderLeft; delimiterIndex <= inorderRight; delimiterIndex++) {
            if (inorder[delimiterIndex] == delimiterValue) {
                break;
            }
        }
        return delimiterIndex;
    }
}


// hash查找index
class Solution2 {
    HashMap<Integer, Integer> map = new HashMap<>();
    public TreeNode buildTree(int[] inorder, int[] postorder) {
        for (int i = 0; i < inorder.length; i++) {
            map.put(inorder[i], i);
        }
        return dfs(inorder, 0, inorder.length - 1, postorder, 0, postorder.length - 1);
    }
    private TreeNode dfs(int[] inorder, int leftInorderLeft, int rightInorderRight,
                         int[] postorder, int leftPostorderLeft, int rightPostorderRight) {
        if (leftInorderLeft > rightInorderRight) {
            return null;
        }
        // 切割点
        int delimiterValue = postorder[rightPostorderRight];
        int delimiterIndex = map.get(delimiterValue);
        TreeNode root = new TreeNode(delimiterValue);

        // 切割，中序数组的左部分（根节点的左子树）
        int leftInorderRight = delimiterIndex - 1;
        // 切割，中序数组的右部分（根节点的右子树）
        int rightInorderLeft = delimiterIndex + 1;

        // 根据左子树和右子树的长度相等来切割后序数组
        // 切割，后序数组的左部分（根节点的左子树）
        int leftPostorderRight = leftPostorderLeft + (leftInorderRight - leftInorderLeft);
        // 切割，后序数组的右部分（根节点的右子树）
        int rightPostorderLeft = leftPostorderRight + 1;

        root.left = dfs(inorder, leftInorderLeft, leftInorderRight, postorder, leftPostorderLeft, leftPostorderRight);
        // 注意去除后序数组的根节点
        root.right = dfs(inorder, rightInorderLeft, rightInorderRight, postorder, rightPostorderLeft, rightPostorderRight - 1);
        return root;
    }
}