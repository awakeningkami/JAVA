package LC257;

import java.util.ArrayList;
import java.util.List;

/*
给你一个二叉树的根节点 root ，按 任意顺序 ，返回所有从根节点到叶子节点的路径。
叶子节点 是指没有子节点的节点。
输入：root = [1,2,3,null,5]
输出：["1->2->5","1->3"]
 */
public class Solution {
    private List<String> res = new ArrayList<>();
    private List<Integer> node = new ArrayList<>();

    public List<String> binaryTreePaths(TreeNode root) {
        if (root == null) {
            return res;
        }
        dfs(root);
        return res;
    }

    private void dfs(TreeNode root) {
        node.add(root.val);
        if (root.left == null && root.right == null) {
            StringBuffer onePath = new StringBuffer();
            // 组成路径，叶子节点后没有 "->"，所以要分开，真麻烦！
            for (int i = 0; i < node.size() - 1; i++) {
                onePath.append(node.get(i)).append("->");
            }
            onePath.append(node.get(node.size() - 1));
            res.add(onePath.toString());
            return;
        }
        if (root.left != null) {
            dfs(root.left);
            node.remove(node.size() - 1);  // 回溯
        }
        if (root.right != null) {
            dfs(root.right);
            node.remove(node.size() - 1);  // 回溯
        }
    }
}
