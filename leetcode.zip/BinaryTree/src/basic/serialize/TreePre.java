package basic.serialize;

import java.util.Arrays;
import java.util.LinkedList;

// https://mp.weixin.qq.com/s/DVX2A1ha4xSecEXLxW_UsA
public class TreePre {
    String SEP = ",";
    String NULL = "#";
    // Encodes a tree to a single string.
    public String serialize(TreeNode root) {
        StringBuilder sb = new StringBuilder();
        serialize(root, sb);
        return sb.toString();
    }

    void serialize(TreeNode root, StringBuilder sb) {
        if (root == null) {
            sb.append(NULL).append(SEP);
            return;
        }
        sb.append(root.val).append(SEP);
        serialize(root.left, sb);
        serialize(root.right, sb);
    }


    // Decodes your encoded data to tree.
    public TreeNode deserialize(String data) {
        LinkedList<String> nodes = new LinkedList<>();
        for (String s : data.split(SEP)) {
            nodes.offerLast(s);
        }
        if (nodes.isEmpty()) {
            return null;
        }
        return deserialize(nodes);
    }

    TreeNode deserialize(LinkedList<String> nodes) {
        String first = nodes.pollFirst();
        if (NULL.equals(first)) {
            return null;
        }
        TreeNode root = new TreeNode(Integer.parseInt(first));
        root.left = deserialize(nodes);
        root.right = deserialize(nodes);
        return root;
    }


    public static void main(String[] args) {
        String s = "a,b,";
        System.out.println(Arrays.toString(s.split(",")));
        System.out.println(s.split(",").length);
    }
}
