package LevelOrder.LC515;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/*
给定一棵二叉树的根节点 root ，请找出该二叉树中每一层的最大值。
 */
public class Solution {
    public List<Integer> largestValues(TreeNode root) {
        List<Integer> res = new ArrayList<>();
        if (root == null) {
            return res;
        }
        LinkedList<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            int levelMax = Integer.MIN_VALUE;
            while (levelSize-- > 0) {
                TreeNode node = queue.poll();
                levelMax = Math.max(levelMax, node.val);
                if (node.left != null) {
                    queue.offer(node.left);
                }
                if (node.right != null) {
                    queue.offer(node.right);
                }
            }
            res.add(levelMax);
        }
        return res;
    }
}
