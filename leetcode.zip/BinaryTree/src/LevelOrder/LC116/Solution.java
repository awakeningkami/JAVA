package LevelOrder.LC116;

import java.util.LinkedList;

/*
给定一个 完美二叉树 ，其所有叶子节点都在同一层，每个父节点都有两个子节点。
填充它的每个 next 指针，让这个指针指向其下一个右侧节点。
如果找不到下一个右侧节点，则将 next 指针设置为 NULL。
 */
public class Solution {
    public Node connect(Node root) {
        if (root == null) {
            return null;
        }
        LinkedList<Node> queue = new LinkedList<>();
        queue.offer(root);
        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            while (levelSize > 0) {
                Node node = queue.poll();
                if (levelSize > 1) {
                    node.next = queue.peek();
                }
                if (node.left != null) {
                    queue.offer(node.left);
                }
                if (node.right != null) {
                    queue.offer(node.right);
                }
                levelSize--;
            }
        }
        return root;
    }

    // 空间复杂度 O(1)
    public Node connect1(Node root) {
        if (root == null) {
            return null;
        }
        Node levelLeft = root;
        while (levelLeft.left != null) {
            Node father = levelLeft;
            while (father != null) {
                father.left.next = father.right;
                if (father.next != null) {
                    father.right.next = father.next.left;
                }
                // 继续向右遍历
                father = father.next;
            }
            // 从下一层的最左边开始遍历
            levelLeft = levelLeft.left;
        }
        return root;
    }

    // 递归
    public Node connect2(Node root) {
        if (root == null) {
            return root;
        }
        if (root.left != null) {
            root.left.next = root.right;
            if (root.next != null) {
                root.right.next = root.next.left;
            }
            connect2(root.left);
            connect2(root.right);
        }
        return root;
    }
}
