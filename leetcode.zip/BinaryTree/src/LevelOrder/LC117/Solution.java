package LevelOrder.LC117;

import java.util.LinkedList;

// LC116是完美二叉树, LC117是普通二叉树
public class Solution {
    public Node connect(Node root) {
        if (root == null) {
            return null;
        }
        LinkedList<Node> queue = new LinkedList<>();
        queue.offer(root);
        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            while (levelSize > 0) {
                Node node = queue.poll();
                if (levelSize > 1) {
                    node.next = queue.peek();
                }
                if (node.left != null) {
                    queue.offer(node.left);
                }
                if (node.right != null) {
                    queue.offer(node.right);
                }
                levelSize--;
            }
        }
        return root;
    }

    // 空间复杂度 O(1)
    public Node connect2(Node root) {
        if (root == null) {
            return null;
        }
        Node levelFirst = root;
        while (levelFirst != null) {
            // 为方便找到下一层的第一个节点（作为parent来处理下层），添加一个哑结点
            Node dummy = new Node();
            Node cur = dummy;
            Node parent = levelFirst;
            // LC116是用父节点完成子节点的连接，所以最后一层不用操作
            // LC117需要借助父节点，同时操作子节点完成连接，所以需要操作最后一层，
            // 退出循环前需要进行一次无用的循环，即if的结果都是false
            while (parent != null) {
                if (parent.left != null) {
                    cur.next = parent.left;
                    cur = cur.next;
                }
                if (parent.right != null) {
                    cur.next = parent.right;
                    cur = cur.next;
                }
                // 继续向右遍历
                parent = parent.next;
            }
            // 从下一层第一个节点开始遍历
            levelFirst = dummy.next;
        }
        return root;
    }
}
