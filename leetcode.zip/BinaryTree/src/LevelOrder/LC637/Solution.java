package LevelOrder.LC637;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/*
给定一个非空二叉树的根节点 root , 以数组的形式返回每一层节点的平均值。
与实际答案相差 10-5 以内的答案可以被接受。
 */
public class Solution {
    public List<Double> averageOfLevels(TreeNode root) {
        List<Double> res = new ArrayList<>();
        LinkedList<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            double levelRes = 0;
            for (int i = 0; i < levelSize; i++){
                TreeNode node = queue.poll();
                levelRes += node.val;
                if (node.left != null) {
                    queue.offer(node.left);
                }
                if (node.right != null) {
                    queue.offer(node.right);
                }
            }
            res.add(levelRes / levelSize);
        }
        return res;
    }
}
