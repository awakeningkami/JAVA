package LevelOrder.LC429;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/*
给定一个 N 叉树，返回其节点值的层序遍历。（即从左到右，逐层遍历）。
树的序列化输入是用层序遍历，每组子节点都由 null 值分隔（参见示例）。
 */
public class Solution {
    public List<List<Integer>> levelOrder(Node root) {
        List<List<Integer>> res = new ArrayList<>();
        if (root == null) {
            return res;
        }
        LinkedList<Node> queue = new LinkedList<>();
        queue.offer(root);
        while (!queue.isEmpty()) {
            List<Integer> levelRes = new ArrayList<>();
            int levelSize = queue.size();
            while (levelSize > 0) {
                Node node = queue.poll();
                levelRes.add(node.val);
                if (node.children != null) {
                    for (Node n : node.children) {
                        queue.offer(n);
                    }
                }
                levelSize--;
            }
            res.add(levelRes);
        }
        return res;
    }
}
