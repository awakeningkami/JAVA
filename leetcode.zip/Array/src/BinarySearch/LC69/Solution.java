package BinarySearch.LC69;

/* x 的平方根
给你一个非负整数 x ，计算并返回 x 的 算术平方根 。
由于返回类型是整数，结果只保留 整数部分 ，小数部分将被 舍去 。
注意：不允许使用任何内置指数函数和算符，例如 pow(x, 0.5) 或者 x ** 0.5 。
 */
public class Solution {
    public int mySqrt(int x) {
        if (x == 0) {
            return 0;
        }
        int left = 1, right = x;
        while (left <= right) {
            int mid = left + ((right - left) >> 1);
            // 用除法，不然会溢出
            if (x / mid >= mid) {   // 要找的是num^2<=x，这个num该是尽可能大的，所以是查找的右边界
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        // 最后left==right时，1. 如果 num*num <= x：left+1, right不变，答案此时应该是right
        //                       因为left*left肯定会大于x，不然怎么会把这个区间排除呢
        //                   2. 如果 num*num > x：left不变, right-1，答案此时应该是right
        //                       x应该是介于right和left之间
        return right;
    }

    public int mySqrt2(int x) {
        if (x == 0) {
            return 0;
        }
        int left = 1, right = x;
        while (left <= right) {
            int mid = left + ((right - left) >> 1);
            // 用除法，不然会溢出
            if (x / mid > mid) {
                left = mid + 1;
            } else if (x / mid < mid) {
                right = mid - 1;
            } else {
                return mid;
            }
        }
        // 根据if的判断条件，left左边的值小于target，right右边的值大于target，最终left==right+1 跳出循环
        // 循环结束后，left左边的部分全部小于target，并以right结尾；right右边的部分全部大于target，并以left为首。
        return right;
    }
}
