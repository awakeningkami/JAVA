package BinarySearch.LC704;

/* 二分查找
给定一个 n 个元素有序的（升序）整型数组 nums 和一个目标值 target  ，
写一个函数搜索 nums 中的 target，如果目标值存在返回下标，否则返回 -1。
你可以假设 nums 中的所有元素是不重复的。
 */
/*
二分法我都用左闭右闭区间
 */
public class Solution {
    public int search(int[] nums, int target) {
        int left = 0, right = nums.length - 1;
        while (left <= right) { // 有等于是因为[left, right]此时也构成合法区间
            int mid = left + (right - left) / 2;
            if (nums[mid] > target) {
                right = mid - 1;    // 因为右闭，mid已经判断了
            } else if (nums[mid] < target) {
                left = mid + 1; // 因为左闭，mid已经判断了
            } else {
                return mid;
            }
        }
        return -1;
    }
}
