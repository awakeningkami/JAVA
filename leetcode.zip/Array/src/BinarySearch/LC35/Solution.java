package BinarySearch.LC35;

/* 搜索插入位置
给定一个排序数组和一个目标值，在数组中找到目标值，并返回其索引。
如果目标值不存在于数组中，返回它将会被按顺序插入的位置。
请必须使用时间复杂度为 O(log n) 的算法。
nums 为 无重复元素 的 升序 排列数组
 */
public class Solution {
    public int searchInsert(int[] nums, int target) {
        int left = 0, right = nums.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (nums[mid] > target) {
                right = mid - 1;
            } else if (nums[mid] < target) {
                left = mid + 1;
            } else {
                return mid;
            }
        }
        // 根据if的判断条件，left左边的值小于target，right右边的值大于target，最终left==right+1 跳出循环
        // 循环结束后，left左边的部分全部小于target，并以right结尾；right右边的部分全部大于target，并以left为首。
        // 所以最终答案一定在left的位置。
        return left;
    }

}
