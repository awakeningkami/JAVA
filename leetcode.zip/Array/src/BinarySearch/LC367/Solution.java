package BinarySearch.LC367;

/* 有效的完全平方数
给定一个 正整数 num ，编写一个函数，如果 num 是一个完全平方数，则返回 true ，否则返回 false 。
1 <= num <= 2^31 - 1
 */
public class Solution {
    public boolean isPerfectSquare(int num) {
        int left = 1, right = num;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            // 为保证不溢出，也不能使用 / ，因为会取整数，结果就错了
            // x 的平方根这道题就可以，因为本来就不需要精确结果
            long temp = (long) mid * mid;
            if (num > temp) {
                left = mid + 1;
            } else if (num < temp) {
                right = mid - 1;
            } else {
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        Solution solution = new Solution();
        solution.isPerfectSquare(5);
    }
}
