package BinarySearch.LC34;

/* 在排序数组中查找元素的第一个和最后一个位置
给你一个按照非递减顺序排列的整数数组 nums，和一个目标值 target。请你找出给定目标值在数组中的开始位置和结束位置。
如果数组中不存在目标值 target，返回 [-1, -1]。
你必须设计并实现时间复杂度为 O(log n) 的算法解决此问题。
 */
/*
二分查找出左右边界
 */
public class Solution {
    public int[] searchRange(int[] nums, int target) {
        int left = leftBorder(nums, target);
        if (left == nums.length || nums[left] != target) { // 说明没有找到相等的, left就是其要插入的位置
            return new int[]{-1, -1};
        }
        int right = rightBorder(nums, target);
        return new int[]{left, right - 1};
    }

    // 看LC35, 退出循环后，left是要插入的位置（无重复有序的情况下，要插入的位置）
    private int rightBorder(int[] nums, int target) {
        int left = 0, right = nums.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (nums[mid] <= target) {    // 寻找右边界，就算left==target，也要继续找
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return left;
    }

    private int leftBorder(int[] nums, int target) {
        int left = 0, right = nums.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (nums[mid] >= target) {    // 寻找左边界，就算left==target，也要继续找
                right = mid - 1;
            } else {
                left = mid + 1;
            }
        }
        System.out.println(left);
        return left;
    }
}

class Solution2 {
    public int[] searchRange(int[] nums, int target) {
        // 寻找左边界(这里寻找第一个 >= target的索引)
        int left = leftBorder(nums, target);
        if (left == nums.length || nums[left] != target) { // 没找到
            return new int[]{-1, -1};
        }
        // 寻找右边界(这里寻找第一个 >= target+1的索引)
        int right = leftBorder(nums, target + 1);
        return new int[]{left, right - 1};
    }

    // 寻找左边界 （看LC35, 退出循环后，left是要插入的位置）
    private int leftBorder(int[] nums, int target) {
        int left = 0, right = nums.length - 1;
        while (left <= right) {
            int mid = left + (right - left) >> 1;
            if (nums[mid] >= target) {
                right = mid - 1;
            } else {
                left = mid + 1;
            }
        }
        return left;
    }
}
