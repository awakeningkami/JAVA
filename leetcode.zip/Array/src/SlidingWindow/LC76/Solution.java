package SlidingWindow.LC76;

/* 最小覆盖子串
给你一个字符串 s 、一个字符串 t 。返回 s 中涵盖 t 所有字符的最小子串。
如果 s 中不存在涵盖 t 所有字符的子串，则返回空字符串 "" 。
对于 t 中重复字符，我们寻找的子字符串中该字符数量必须不少于 t 中该字符数量。
如果 s 中存在这样的子串，我们保证它是唯一的答案。
输入：s = "ADOBECODEBANC", t = "ABC"
输出："BANC"
 */

import java.util.HashMap;

/*
滑动窗口
1. 记录窗口中的字符出现次数；和 t 字符出现的次数
2. 如果窗口中该字符的个数小于等于 t 的，移动right
3. 如果窗口中该字符的个数大于 t的，若left的字符没用，那么就可以移动left了
 */
public class Solution {
    public String minWindow(String s, String t) {
        HashMap<Character, Integer> hs = new HashMap<>();
        HashMap<Character, Integer> ht = new HashMap<>();
        int count = 0; // 维护窗口中满足t串的元素的个数
        String res = "";
        int minLen = Integer.MAX_VALUE; // 为什么不能用res.length()判断，因为res初始值为""，而minLen初始值必须最大
        for (int i = 0; i < t.length(); i++) {
            ht.put(t.charAt(i), ht.getOrDefault(t.charAt(i), 0) + 1);
        }

        for (int left = 0, right = 0; right < s.length(); right++) {
            char tempRight = s.charAt(right);
            hs.put(tempRight, hs.getOrDefault(tempRight, 0) + 1);
            // 该字符是必须的
            if (ht.getOrDefault(tempRight, 0) >= hs.get(tempRight)) {
                count ++;
            }
            //收缩滑动窗口
            //如果左边界的值不在ht表中 或者 它在hs表中的出现次数多于ht表中的出现次数
            // 这里一定要防止left > right （s = "a", t = "b"）
            while (left < right && (!ht.containsKey(s.charAt(left)) || hs.get(s.charAt(left)) > ht.get(s.charAt(left)))) {
                hs.put(s.charAt(left), hs.get(s.charAt(left)) - 1);
                left++;
            }

            // 满足条件的一个结果
            if (count == t.length() && right - left + 1 < minLen) {
                minLen = right - left + 1;
                res = s.substring(left, right + 1);
            }
        }
        return res;
    }

    public static void main(String[] args) {
        String s =  "ADOBECODEBANC";
        String t = "ABC";
        Solution solution = new Solution();
        String s1 = solution.minWindow(s, t);
        System.out.println(s1);
    }
}
