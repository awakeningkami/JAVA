package LC54;

import java.util.ArrayList;
import java.util.List;

/* 螺旋矩阵
给你一个 m 行 n 列的矩阵 matrix ，请按照 顺时针螺旋顺序 ，返回矩阵中的所有元素。
 */
/*
参考LC59：人家是矩阵，所以for循环可以不加条件判断，最后一圈并不会反向重复遍历
        （因为最后一圈前，left=right，top=bottom；而随后的top++，right--，bottom--都保证了不会反向遍历）
此题存在矩形情况，所以for循环必须加判断，如果数够了就break，防止反向重复遍历
 */
public class Solution {
    public List<Integer> spiralOrder(int[][] matrix) {
        int m = matrix.length;
        int n = matrix[0].length;
        List<Integer> res = new ArrayList<>();
        int left = 0, top = 0, right = n - 1, bottom = m - 1;
        while (res.size() < m * n) {
            for (int j = left; j <= right && res.size() < m * n; j++) {
                res.add(matrix[top][j]);
            }
            top++;
            for (int i = top; i <= bottom && res.size() < m * n ; i++) {
                res.add(matrix[i][right]);
            }
            right--;
            for (int j = right; j >= left && res.size() < m * n; j--) {
                res.add(matrix[bottom][j]);
            }
            bottom--;
            for (int i = bottom; i >= top && res.size() < m * n; i--) {
                res.add(matrix[i][left]);
            }
            left++;
        }
        return res;
    }

    public static void main(String[] args) {
        int[][] matrix = new int[][]{{1,2,3, 4}};
        Solution solution = new Solution();
        List<Integer> integers = solution.spiralOrder(matrix);
        System.out.println(integers);
    }
}
