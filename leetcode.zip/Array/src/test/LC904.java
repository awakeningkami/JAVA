package test;

public class LC904 {
    public int totalFruit(int[] fruits) {
        int res = 0;
        int[] basket = new int[]{fruits[0], fruits[0]};
        for (int left = 0, right = 0; right < fruits.length; right++) {
            if (fruits[right] == basket[0] || fruits[right] == basket[1]) {
                res = Math.max(res, right - left + 1);
            } else {
                left = right - 1;
                basket[0] = fruits[left];
                basket[1] = fruits[right];
                while (left >= 1 && fruits[left - 1] == basket[0]) {
                    left--;
                }
                res = Math.max(res, right - left + 1);
            }
        }
        return res;
    }
}
