package test;

import java.util.HashMap;
public class LC76 {
    public String minWindow(String s, String t) {
        HashMap<Character, Integer> hs = new HashMap<>();
        HashMap<Character, Integer> ht = new HashMap<>();
        int count = 0;
        String res = "";
        int minLen = Integer.MAX_VALUE;
        for (int i = 0; i < t.length(); i++) {
            ht.put(t.charAt(i), ht.getOrDefault(t.charAt(i), 0) + 1);
        }

        for (int left = 0, right = 0; right < s.length(); right++) {
            char tempRight = s.charAt(right);
            hs.put(tempRight, hs.getOrDefault(tempRight, 0) + 1);
            if (ht.getOrDefault(tempRight, 0) >= hs.get(tempRight)) {
                count++;
            }

            while (left < right && (!ht.containsKey(s.charAt(left)) || hs.get(s.charAt(left)) > ht.get(s.charAt(left)))) {
                hs.put(s.charAt(left), hs.get(s.charAt(left)) - 1);
                left++;
            }
            if (count == t.length() && right - left + 1 < minLen) {
                minLen = right - left  + 1;
                res = s.substring(left, right + 1);
            }
        }
        return res;
    }
}
