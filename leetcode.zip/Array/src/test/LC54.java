package test;

import java.util.ArrayList;
import java.util.List;

public class LC54 {
    public List<Integer> spiralOrder(int[][] matrix) {
        int m = matrix.length;
        int n = matrix[0].length;
        int left = 0, top = 0, right = n - 1, bottom = m - 1;
        List<Integer> res = new ArrayList<>();
        while (res.size() < m * n) {
            for (int j = left; j <= right && res.size() < m * n; j++) {
                res.add(matrix[top][j]);
            }
            top++;
            for (int i = top; i <= bottom && res.size() < m * n; i++) {
                res.add(matrix[i][right]);
            }
            right--;
            for (int j = right; j >= left && res.size() < m * n; j--) {
                res.add(matrix[bottom][j]);
            }
            bottom--;
            for (int i = bottom; i >= top && res.size() < m * n; i--) {
                res.add(matrix[i][left]);
            }
            left++;
        }
        return res;
    }
}
