package LC332;

/*
给你一份航线列表 tickets ，其中 tickets[i] = [fromi, toi] 表示飞机出发和降落的机场地点。请你对该行程进行重新规划排序。

所有这些机票都属于一个从 JFK（肯尼迪国际机场）出发的先生，所以该行程必须从 JFK 开始。
如果存在多种有效的行程，请你按字典排序返回最小的行程组合。

例如，行程 ["JFK", "LGA"] 与 ["JFK", "LGB"] 相比就更小，排序更靠前。
假定所有机票至少存在一种合理的行程。且所有的机票 必须都用一次 且 只能用一次。
 */

import java.util.*;

/*
本题的重点在于容器的选取，
因为一个机场映射多个机场，所以我们就需要 Map<String, ?>
1. 如果是 Map<String, String>，我们使用过机票就要进行删除（避免重复使用），那么迭代器将失效，
    递归时报错 ConcurrentModificationException，而且还是无序的
2. 所以我们要找到一个对数据进行排序的容器，而且还要容易增删元素，
            from             to     number
    HashMap<String, TreeMap<String, Integer>>
 */

/*
API: Map: putIfAbsent(k, v) 如果map中没有k，就添加，否则不添加
          put(k,v) 没有就添加，有就修改原值
          getOrDefault(key, defaultValue) 有k就返回其v，没有就返回defaultValue
 */
public class Solution {
    List<String> res = new ArrayList<>();
    HashMap<String, TreeMap<String, Integer>> map = new HashMap<>();
    public List<String> findItinerary(List<List<String>> tickets) {
        for (List<String> ticket : tickets) {
            String from = ticket.get(0);
            String to = ticket.get(1);
            map.putIfAbsent(from, new TreeMap<>());
            TreeMap<String, Integer> treeMap = map.get(from);
            // Map有个函数 getOrDefault(key, defaultValue)
            treeMap.put(to, treeMap.getOrDefault(to, 0) + 1);
        }
        res.add("JFK");
        backtracking(tickets.size());
        return res;
    }

    // 找到就提前返回，所以用boolean
    private boolean backtracking(int ticketNum) {
        if (res.size() == ticketNum + 1) {
            return true;
        }
        TreeMap<String, Integer> tos = map.get(res.get(res.size() - 1));
        // 不存在这种机票
        if (tos == null) {
            return false;
        }
        for (String s : tos.keySet()) {
            // 机票已经用过了
            if (tos.get(s) == 0) {
                continue;
            }

            res.add(s);
            tos.put(s, tos.get(s) - 1);

            if (backtracking(ticketNum)){
                return true;
            }

            res.remove(res.size() - 1);
            tos.put(s, tos.get(s) + 1);

        }
        return false;
    }

}
