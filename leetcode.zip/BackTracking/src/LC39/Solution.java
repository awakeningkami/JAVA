package LC39;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
给你一个 无重复元素 的整数数组 candidates 和一个目标整数 target ，
找出 candidates 中可以使数字和为目标数 target 的 所有不同组合 ，并以列表形式返回。
你可以按 任意顺序 返回这些组合。

candidates 中的 同一个 数字可以 无限制重复被选取 。如果至少一个数字的被选数量不同，则两种组合是不同的。
对于给定的输入，保证和为target 的不同组合数少于 150 个。
 */
public class Solution {
    List<List<Integer>> res = new ArrayList<>();
    List<Integer> path = new ArrayList<>();
    int sum;
    public List<List<Integer>> combinationSum(int[] candidates, int target) {
        backtracking(candidates, target, 0);
        return res;
    }
    private void backtracking(int[] candidates, int target, int startIndex) {
        if (sum > target) {
            return;
        }
        if (sum == target) {
            res.add(new ArrayList<>(path));
            return;
        }
        for (int i = startIndex; i < candidates.length; i++) {
            path.add(candidates[i]);    // 处理
            sum += candidates[i];
            backtracking(candidates, target, i);    // 递归,不用i+1,表示可以重复读取当前的数
            path.remove(path.size() - 1);   // 回溯
            sum -= candidates[i];
        }
    }
}

/*
上面的方法无法剪枝，为了剪枝，先排序
 */
class Solution2 {
    List<List<Integer>> res = new ArrayList<>();
    List<Integer> path = new ArrayList<>();
    int sum;
    public List<List<Integer>> combinationSum(int[] candidates, int target) {
        Arrays.sort(candidates);
        backtracking(candidates, target, 0);
        return res;
    }
    private void backtracking(int[] candidates, int target, int startIndex) {
//        if (sum > target) {   // 剪枝后不需要
//            return;
//        }
        if (sum == target) {
            res.add(new ArrayList<>(path));
            return;
        }
        for (int i = startIndex; i < candidates.length && sum + candidates[i] <= target; i++) { // 排序后剪枝
            path.add(candidates[i]);    // 处理
            sum += candidates[i];
            backtracking(candidates, target, i);    // 递归,不用i+1,表示可以重复读取当前的数
            path.remove(path.size() - 1);   // 回溯
            sum -= candidates[i];
        }
    }
}