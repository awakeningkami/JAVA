package LC40;

import java.util.*;

/*
给定一个候选人编号的集合 candidates 和一个目标数 target ，找出 candidates 中所有可以使数字和为 target 的组合。

candidates 中的每个数字在每个组合中只能使用 一次 。

注意：解集不能包含重复的组合。
 */

/*
代码 LC39
在同一树层中去重，且不能在同一树支去重
树层去重的话，需要对数组排序！
 */
class Solution {
    List<List<Integer>> res = new ArrayList<>();
    List<Integer> path = new ArrayList<>();
    int sum;

    public List<List<Integer>> combinationSum(int[] candidates, int target) {
        Arrays.sort(candidates);
        backtracking(candidates, target, 0);
        return res;
    }

    private void backtracking(int[] candidates, int target, int startIndex) {
        if (sum == target) {
            res.add(new ArrayList<>(path));
            return;
        }
        for (int i = startIndex; i < candidates.length && sum + candidates[i] <= target; i++) { // 排序后剪枝
            if (i > startIndex && candidates[i] == candidates[i - 1]) { // 同一树层去重，同一树支不去重，通过 i > startIndex实现，太秒了
                // 当调用递归时，树深度就会加一，相当于同一树枝，而此时i == startIndex，不去重
                // 在for循环中，相当于同一树层，此时 i > startIndex，进行去重
                continue;
            }
            path.add(candidates[i]);
            sum += candidates[i];
            backtracking(candidates, target, i + 1);
            path.remove(path.size() - 1);
            sum -= candidates[i];
        }
    }
}
