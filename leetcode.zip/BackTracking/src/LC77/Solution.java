package LC77;

import java.util.ArrayList;
import java.util.List;

/*
给定两个整数 n 和 k，返回范围 [1, n] 中所有可能的 k 个数的组合。
你可以按 任何顺序 返回答案。
 */
public class Solution {
    List<Integer> path = new ArrayList<>();
    List<List<Integer>> res = new ArrayList<>();
    public List<List<Integer>> combine(int n, int k) {
        backtracking(n, k, 1);
        return res;
    }

    public void backtracking(int n, int k, int startIndex) {
        if (path.size() == k) {
            res.add(new ArrayList<>(path)); // 注意path是引用数据类型
            // res.add(path);  切记这是错误的，path始终都是同一个引用
            return;
        }
        for (int i = startIndex; i <= n - (k - path.size()) + 1; i++) { // 剪枝,因为是+1递增的，所以循环结束位置可以确定，如果不是就要注意了
            path.add(i);    // 处理节点
            backtracking(n, k, i + 1); // 递归
            path.remove(path.size() - 1);   // 回溯
        }
    }

    public static void main(String[] args) {
        Solution solution = new Solution();
        List<List<Integer>> lists = solution.combine(4, 2);
        System.out.println(lists);
    }
}
