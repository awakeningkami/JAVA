package test;

public class LC37 {
    private boolean backtracking(char[][] board) {
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                if (board[row][col] != '.') {
                    continue;
                }
                for (char i = '1'; i <= '9'; i++) {
                    if (!isVaild(board, row, col, i)) {
                        board[row][col] = i;
                        if (backtracking(board)) {
                            return true;
                        }
                        board[row][col] = '.';
                    }
                }
                return false;
            }
        }
        return true;
    }

    private boolean isVaild(char[][] board, int row, int col, char i) {
        return false;
    }
}
