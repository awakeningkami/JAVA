package test;

import java.util.ArrayList;
import java.util.List;

public class LC93 {
    List<String> res = new ArrayList<>();
    StringBuilder path = new StringBuilder();
    int number;

    public List<String> restoreIpAddresses(String s) {
        backtracking(s, 0);
        return res;
    }

    private void backtracking(String s, int index) {
        if (index == s.length() && number == 4) {
            res.add(path.toString());
            return;
        } else if (number == 4) {
            return;
        }

        for (int i = index; i < s.length() && i < index + 3; i++) {
            String subStr = s.substring(index, i + 1);
            if (!isValid(subStr)) {
                break;
            }
            path.append(subStr);
            if (number < 3) {
                path.append(".");
            }
            number++;

            backtracking(s, i + 1);
            number--;
            path.delete(index + number, path.length());
        }
    }

    private boolean isValid(String str) {
        if ((Integer.parseInt(str) > 255) || (str.length() > 1 && str.startsWith("0"))) {
            return false;
        }
        return true;
    }
}
