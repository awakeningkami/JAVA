package test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

public class LC332 {
    List<String> res = new ArrayList<>();
    HashMap<String, TreeMap<String, Integer>> map = new HashMap<>();
    public List<String> findItinerary(List<List<String>> tickets) {
        for (List<String> ticket : tickets) {
            String from = ticket.get(0);
            String to = ticket.get(1);
            map.putIfAbsent(from, new TreeMap<>());
            TreeMap<String, Integer> treeMap = map.get(from);
            // Map有个函数 getOrDefault(key, defaultValue)
            treeMap.put(to, treeMap.getOrDefault(to, 0) + 1);
        }
        res.add("JFK");
        backtracking(tickets.size());
        return res;
    }

    private boolean backtracking(int ticketNum) {
        if (res.size() == ticketNum + 1) {
            return true;
        }
        TreeMap<String, Integer> tos = map.get(res.get(res.size() - 1));
        if (tos == null) {
            return false;
        }
        for (String s : tos.keySet()) {
            if (tos.get(s) == 0) {
                continue;
            }

            res.add(s);
            tos.put(s, tos.get(s) - 1);

            if (backtracking(ticketNum)) {
                return true;
            }

            res.remove(res.size() - 1);
            tos.put(s, tos.get(s) + 1);
        }

        return false;
    }
}
