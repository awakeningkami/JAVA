package LC17;

/*
给定一个仅包含数字 2-9 的字符串，返回所有它能表示的字母组合。答案可以按 任意顺序 返回。
给出数字到字母的映射如下（与电话按键相同）。注意 1 不对应任何字母。

 */

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Solution {
    static final Map<Character, String> MAP = Map.of(
            '2', "abc", '3', "def", '4', "ghi", '5', "jkl",
            '6', "mno", '7', "pqrs", '8', "tuv", '9', "wxyz"
    );
    List<String> res = new ArrayList<>();
    StringBuilder path = new StringBuilder();

    public List<String> letterCombinations(String digits) {
        if (digits == null || digits.length() == 0) {
            return res;
        }
        backtracking(digits, 0);
        return res;
    }

    private void backtracking(String digits, int index) {
        if (path.length() == digits.length()) {
            res.add(path.toString());   // toString()是就是new一个String
            return;
        }
        String letters = MAP.get(digits.charAt(index));
        for (int i = 0; i < letters.length(); i++) {
            path.append(letters.charAt(i)); // 处理节点
            backtracking(digits, index + 1);    // 递归，index代表下个数字
            path.deleteCharAt(path.length() - 1);   // 回溯
        }
    }

    public static void main(String[] args) {
        Solution solution = new Solution();
        List<String> list = solution.letterCombinations("23");
        System.out.println(list);
    }
}
