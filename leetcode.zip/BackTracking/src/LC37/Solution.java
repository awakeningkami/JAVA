package LC37;

/*
编写一个程序，通过填充空格来解决数独问题。

数独的解法需 遵循如下规则：

数字 1-9 在每一行只能出现一次。
数字 1-9 在每一列只能出现一次。
数字 1-9 在每一个以粗实线分隔的 3x3 宫内只能出现一次。
数独部分空格内已填入了数字，空白格用 '.' 表示。
 */

/*
之前的方法不能用，因为没法知道终止条件（我认为只要找到终止条件也可以用之前的方法）
那么我们就遍历整个棋盘，直到全部写满
 */
public class Solution {
    public void solveSudoku(char[][] board) {
        backtracking(board);
    }

    private boolean backtracking(char[][] board) {
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                // 每次都是从头遍历，这个判断能保证去填空位置
                if (board[row][col] != '.') {
                    continue;
                }
                // 直接用 char
                for (char i = '1'; i <= '9'; i++) {
                    if (isValid(board, row, col, i)) {
                        board[row][col] = i;
                        if (backtracking(board)) {
                            return true;
                        }
                        board[row][col] = '.';
                    }
                }
                return false;  // 啥，1-9都不符合？那就无解
            }
        }
        return true;
    }

    private boolean isValid(char[][] board, int row, int col, char val) {
        // 检查这一行
        for (int i = 0; i < 9; i++) {
            if (board[row][i] == val) {
                return false;
            }
        }
        // 检查这一列
        for (int i = 0; i < 9; i++) {
            if (board[i][col] == val) {
                return false;
            }
        }
        // 检查 宫内
        int rowStart = row / 3 * 3;
        int colStart = col / 3 * 3;
        for (int i = rowStart; i < rowStart + 3; i++) {
            for (int j = colStart; j < colStart + 3; j++) {
                if (board[i][j] == val) {
                    return false;
                }
            }
        }
        return true;
    }
}
