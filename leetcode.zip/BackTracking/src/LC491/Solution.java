package LC491;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/*
给你一个整数数组 nums ，找出并返回所有该数组中不同的递增子序列，
递增子序列中 至少有两个元素 。你可以按 任意顺序 返回答案。
数组中可能含有重复元素，如出现两个整数相等，也可以视作递增序列的一种特殊情况。

输入：nums = [4,6,7,7]
输出：[[4,6],[4,6,7],[4,6,7,7],[4,7],[4,7,7],[6,7],[6,7,7],[7,7]]
 */
/*
递增序列可以用 i > startIndex && candidates[i] == candidates[i - 1] 树层中去重，树支不去重；
但是无序的不可以，只能用set来保证树层中不重复
 */
public class Solution {
    List<List<Integer>> res = new ArrayList<>();
    List<Integer> path = new ArrayList<>();

    public List<List<Integer>> findSubsequences(int[] nums) {
        backtracking(nums, 0);
        return res;
    }

    private void backtracking(int[] nums, int index) {
        if (path.size() > 1) {
            res.add(new ArrayList<>(path));
        }
        // for循环是横向遍历，也就是树层，此时共用一个set即可完成去重
        // 每递归一次，树的深度+1，都会new一个自己的set，可以保证树枝不去重
        HashSet<Integer> set = new HashSet<>();
        for (int i = index; i < nums.length; i++) {
            // 如果重复，或者不是递增的
            if (set.contains(nums[i]) || (!path.isEmpty() && path.get(path.size() - 1) > nums[i])) {
                continue;
            }
            path.add(nums[i]);
            set.add(nums[i]);
            backtracking(nums, i + 1);
            path.remove(path.size() - 1);
        }
    }

    public static void main(String[] args) {
        int[] nums = new int[]{4, 7, 6, 7};
        Solution solution = new Solution();
        List<List<Integer>> subsequences = solution.findSubsequences(nums);
        System.out.println(subsequences);
    }
}
