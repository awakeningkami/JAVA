package LC47;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

/*
给定一个可包含重复数字的序列 nums ，按任意顺序 返回所有不重复的全排列。
输入：nums = [1,1,2]
输出：
[[1,1,2],
 [1,2,1],
 [2,1,1]]
 */
public class Solution {
    List<List<Integer>> res = new ArrayList<>();
    List<Integer> path = new ArrayList<>();
    // 排列问题需要isUsed记录是否使用过
    boolean[] isUsed;

    public List<List<Integer>> permuteUnique(int[] nums) {
        isUsed = new boolean[nums.length];
        backtracking(nums);
        return res;
    }

    private void backtracking(int[] nums) {
        if (path.size() == nums.length) {
            res.add(new ArrayList<>(path));
            return;
        }
        HashSet<Integer> set = new HashSet<>();
        for (int i = 0; i < nums.length; i++) {
            // 树层去重
            if (set.contains(nums[i])) {
                continue;
            }

            if (isUsed[i]) {
                continue;
            }
            path.add(nums[i]);
            set.add(nums[i]);
            isUsed[i] = true;
            backtracking(nums);
            path.remove(path.size() - 1);
            isUsed[i] = false;
        }
    }

    public static void main(String[] args) {
        int[] nums = new int[]{1,1,2};
        Solution solution = new Solution();
        List<List<Integer>> permute = solution.permuteUnique(nums);
        System.out.println(permute);
    }
}

/*
对同一节点下本层去重，不利用set记录的话，所有去重都要先排序；那么不能排序的当然只能用set；
排列问题的去重和组合问题不太一样，但都是树层去重（排列也可以树枝去重，不太好理解）
排列最大的特点就是，每次递归，都要从头遍历。所以很难保证树层去重的同时树枝不去重；
 */
/*
利用isUsed，当 isUsed[i - 1] == true，说明同一树枝nums[i - 1]使用过，不用去重
           当 isUsed[i - 1] == false，说明同一树层nums[i - 1]使用过，要去重
           （因为是按顺序遍历的，你现在是false，那么你一定使用过了）
           这样的目的主要是为了区分树枝和树层，这是排列和组合问题去重的不同之处

 */
class Solution2 {
    List<List<Integer>> res = new ArrayList<>();
    List<Integer> path = new ArrayList<>();
    // 排列问题需要isUsed记录是否使用过
    boolean[] isUsed;

    public List<List<Integer>> permuteUnique(int[] nums) {
        isUsed = new boolean[nums.length];
        // 不用set就要排序
        Arrays.sort(nums);
        backtracking(nums);
        return res;
    }

    private void backtracking(int[] nums) {
        if (path.size() == nums.length) {
            res.add(new ArrayList<>(path));
            return;
        }
        for (int i = 0; i < nums.length; i++) {
            if (isUsed[i]) {
                continue;
            }
            // 树层去重
            if (i > 0 && !isUsed[i - 1] && nums[i] == nums[i - 1]){
                continue;
            }
            path.add(nums[i]);
            isUsed[i] = true;
            backtracking(nums);
            path.remove(path.size() - 1);
            isUsed[i] = false;
        }
    }

    public static void main(String[] args) {
        int[] nums = new int[]{1,1,2};
        Solution2 solution = new Solution2();
        List<List<Integer>> permute = solution.permuteUnique(nums);
        System.out.println(permute);
    }
}

