package LC131;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
给你一个字符串 s，请你将 s 分割成一些子串，使每个子串都是 回文串 。返回 s 所有可能的分割方案。
回文串 是正着读和反着读都一样的字符串。
 */
/*
切割问题类似组合问题
例如对于字符串abcdef：
组合问题：选取一个a之后，在bcdef中再去选取第二个，选取b之后在cdef中在选组第三个.....。
切割问题：切割一个a之后，在bcdef中再去切割第二段，切割b之后在cdef中在切割第三段.....。
 */
public class Solution {
    List<List<String>> res = new ArrayList<>();
    List<String> path = new ArrayList<>();
    boolean[][] dp;
    public List<List<String>> partition(String s) {
        dp = new boolean[s.length()][s.length()];
        isPalindrome(s, dp);
        backtracking(s, 0);
        return res;
    }

    private void backtracking(String s, int index) {
        if (index == s.length()) {
            res.add(new ArrayList<>(path));
            return;
        }

        for (int i = index; i < s.length(); i++) {
            if (dp[index][i]) {
                path.add(s.substring(index, i + 1));    // substring() 右边是开区间
                backtracking(s, i + 1);
                path.remove(path.size() - 1);
            }
        }
    }

    private void isPalindrome(String s, boolean[][] dp) {
        // dp[i][j]：s[i..j]是不是回文串
        for (int i = s.length() -1 ; i >= 0; i--) {
            for (int j = i; j < s.length(); j++) {
                if (j == i) {
                    dp[i][j] = true;
                } else if (j - i == 1) {
                    dp[i][j] = s.charAt(i) == s.charAt(j);
                } else {
                    dp[i][j] = dp[i + 1][j - 1] && (s.charAt(i) == s.charAt(j));
                }
            }
        }
    }

    public static void main(String[] args) {
        Solution solution = new Solution();
        List<List<String>> aab = solution.partition("a");
        System.out.println(aab);
    }
}
