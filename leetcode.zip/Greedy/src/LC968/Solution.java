package LC968;

/*监控二叉树
给定一个二叉树，我们在树的节点上安装摄像头。
节点上的每个摄影头都可以监视其父对象、自身及其直接子对象。
计算监控树的所有节点所需的最小摄像头数量。
 */
/*
局部最优：让叶子节点的父节点安摄像头

 */
public class Solution {
    int res = 0;
    public int minCameraCover(TreeNode root) {
        // 对根节点的状态做检验,防止根节点是无覆盖状态
        if(dfs(root) == 0) {
            return res + 1;
        } else {
            return res;
        }
    }

    /*
    节点状态：
    0 : 无覆盖
    1 : 覆盖到了，且该节点有摄像头
    2 : 覆盖到了，但是该节点没有摄像头
    空节点不能是无覆盖的状态，这样叶子节点就要放摄像头了；
    空节点也不能是有摄像头的状态，这样叶子节点的父节点就没有必要放摄像头了；
    所以空节点的状态只能是有覆盖
     */
    private int dfs(TreeNode root) {
        // 空节点，当做覆盖到了
        if (root == null) {
            return 2;
        }
        int left = dfs(root.left);
        int right = dfs(root.right);
        // 左右都被覆盖了，但是没摄像头，那么root就是没有覆盖
        if (left == 2 && right == 2) {
            return 0;
        // 左/右 有没覆盖的，那么root就要放摄像头
        } else if (left == 0 || right == 0) {
            res++;
            return 1;
        // 左/右 有摄像头，那么root就是覆盖（无摄像头）
        } else {
            return 2;
        }
    }

}
