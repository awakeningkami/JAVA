package LC55;

/*跳跃游戏
给定一个非负整数数组 nums ，你最初位于数组的 第一个下标 。
数组中的每个元素代表你在该位置可以跳跃的最大长度。
判断你是否能够到达最后一个下标。
 */

public class Solution {
    // 倒序遍历，如果前一个可以到达当前位置，就把前一个位置标绿色，不能到达就标红色
    // （用一个变量记录最少应该跳到的位置，即绿色位置）
    public boolean canJump(int[] nums) {
        int least = nums.length - 1;
        for (int i = nums.length - 2; i >= 0; i--) {
            if (i + nums[i] >= least) {
                least = i;
            }
        }
        return least == 0;
    }

    // 正序遍历，记录当前位置可以到达的最远距离，如果i超过了最远距离，那么证明不可达（都跳不到i了）
    public boolean canJump1(int[] nums) {
        int reach = 0;
        for (int i = 0; i < nums.length; i++) {
            if (i > reach) {
                return false;
            }
            reach = Math.max(reach, i + nums[i]);
        }
        return true;
    }
}
