package LC45;

/*跳跃游戏 II
给你一个非负整数数组 nums ，你最初位于数组的第一个位置。
数组中的每个元素代表你在该位置可以跳跃的最大长度。
你的目标是使用最少的跳跃次数到达数组的最后一个位置。
假设你总是可以到达数组的最后一个位置。
 */
/*
每次在上次能跳到的范围（end）内选择一个能跳的最远的位置（也就是能跳到reach位置的点）作为下次的起跳点！
 */
public class Solution {
    public int jump(int[] nums) {
        int reach = 0;  // 能跳到的最远位置
        int end = 0;    // 上次跳跃可达到的最远位置
        int res = 0;    // 步数
        /*
        在遍历数组时，我们不访问最后一个元素，这是因为在访问最后一个元素之前，
        我们的边界一定大于等于最后一个位置，否则就无法跳到最后一个位置了。
        如果访问最后一个元素，在边界正好为最后一个位置的情况下，我们会增加一次「不必要的跳跃次数」，
        因此我们不必访问最后一个元素。
         */
        for (int i = 0; i < nums.length - 1; i++) {
            reach = Math.max(reach, i + nums[i]);
            if (i == end) { // end之前总要跳一次的，不关心从哪里跳的
                end = reach;
                res++;
            }
        }
        return res;
    }

    public static void main(String[] args) {
        Solution solution = new Solution();
        int[] nums = new int[]{2, 3, 1, 2, 4, 2, 3};
        solution.jump(nums);
    }
}
