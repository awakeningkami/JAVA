package LC738;

import java.util.Arrays;

/*单调递增的数字
当且仅当每个相邻位数上的数字 x 和 y 满足 x <= y 时，我们称这个整数是单调递增的。
给定一个整数 n ，返回 小于或等于 n 的最大数字，且数字呈 单调递增 。
 */
/*
char[i-1] > char[i]，则 char[i-1] - 1, 后面的数字全变为9
 */
public class Solution {
    public int monotoneIncreasingDigits(int n) {
        char[] arr = String.valueOf(n).toCharArray();
        int flag = arr.length;  // 标记要改变的位置，此位置后面的都数字都要变为9
        for (int i = arr.length - 2; i >= 0; i--) {
            if (arr[i] > arr[i + 1]) {
                arr[i]--;
                flag = i + 1;
            }
        }
        for (int i = flag; i < arr.length; i++) {
            arr[i] = '9';
        }
        return Integer.parseInt(new String(arr));
    }

    public static void main(String[] args) {
        Solution solution = new Solution();
        int i = solution.monotoneIncreasingDigits(10);
        System.out.println(i);
    }

}
