package LC134;

/* 加油站
在一条环路上有 n 个加油站，其中第 i 个加油站有汽油 gas[i] 升。
你有一辆油箱容量无限的的汽车，从第 i 个加油站开往第 i+1 个加油站需要消耗汽油 cost[i] 升。
你从其中的一个加油站出发，开始时油箱为空。
给定两个整数数组 gas 和 cost ，如果你可以绕环路行驶一周，则返回出发时加油站的编号，否则返回 -1 。
如果存在解，则 保证 它是 唯一 的。
 */

/*
pure = gas-cost,如果sum(pure)>0,说明可以走完，在此基础上寻找起始点：
    1. 肯定是从pure[i] > 0开始    (start)
    2. 如果sum > 0 那么接着走；
    3. 当sum < 0 (end)时就要重新找开始位置了；
        [start, end) 存的油不够，因为start的油是够用的，所以在 (start, end) 里任何一点出发，
        存的油会比现在还少，还是会被end榨干；
    4.  从 end+1 出发，如果走到了n-1，就证明我们要的就是这个start
        因为第一步已经判断可以走完，现在攒的油肯定足以够  [0, start)用；
 */
public class Solution {
    public int canCompleteCircuit(int[] gas, int[] cost) {
        int cur = 0;
        int total = 0;
        int start = 0;
        for (int i = 0; i < gas.length; i++) {
            cur += gas[i] - cost[i];
            total += gas[i] - cost[i];
            if (cur < 0) {
                start = i + 1;
                cur = 0;
            }
        }
        return total < 0 ? -1 : start;
    }
}
