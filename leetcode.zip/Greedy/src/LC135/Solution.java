package LC135;

/*分发糖果
n 个孩子站成一排。给你一个整数数组 ratings 表示每个孩子的评分。
你需要按照以下要求，给这些孩子分发糖果：
每个孩子至少分配到 1 个糖果。
相邻两个孩子评分更高的孩子会获得更多的糖果。
请你给每个孩子分发糖果，计算并返回需要准备的 最少糖果数目 。
 */

import java.util.Arrays;

/*
我们可以将 相邻的孩子中，评分高的孩子必须获得更多的糖果 这句话拆分为两个规则，分别处理。
左规则：当 ratings[i−1]<ratings[i] 时，i号学生的糖果数量将比 i - 1号孩子的糖果数量多。
右规则：当 ratings[i]>ratings[i+1] 时，i号学生的糖果数量将比 i + 1号孩子的糖果数量多。
 */
public class Solution {
    public int candy(int[] ratings) {
        int[] res = new int[ratings.length];
        res[0] = 1;
        // 左规则
        for (int i = 1; i < ratings.length; i++) {
            if (ratings[i] > ratings[i - 1]) {
                res[i] = res[i - 1] + 1;
            } else {
                res[i] = 1;
            }
        }
        System.out.println(Arrays.toString(res));
        int count = res[ratings.length - 1];
        // 右规则
        for (int i = ratings.length - 2; i >= 0; i--) {
            if (ratings[i] > ratings[i + 1]) {
                res[i] = Math.max(res[i + 1] + 1, res[i]);
            }
            count += res[i];
        }
        System.out.println(Arrays.toString(res));
        return count;
    }

    public static void main(String[] args) {
        Solution solution = new Solution();
        int[] ratings = new int[]{1,0,2};
        int candy = solution.candy(ratings);
        System.out.println(candy);
    }
}
