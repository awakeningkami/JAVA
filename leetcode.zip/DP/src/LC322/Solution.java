package LC322;

/*
给你一个整数数组 coins ，表示不同面额的硬币；以及一个整数 amount ，表示总金额。
计算并返回可以凑成总金额所需的 最少的硬币个数 。如果没有任何一种硬币组合能组成总金额，返回-1 。
你可以认为每种硬币的数量是无限的。
 */

// 完全背包
class Solution {
    public static int coinChange(int[] coins, int amount) {
        // dp[j] ：凑成金额 j 的最少硬币个数为 dp[j]
        int[] dp = new int[amount + 1];
        dp[0] = 0;
        for (int j = 1; j <= amount; j++) {
            dp[j] = Integer.MAX_VALUE;
        }

        for (int i = 0; i < coins.length; i++) {
            for (int j = coins[i]; j <= amount; j++) {
                // 只有dp[j-coins[i]]不是初始最大值时，该位才有选择的必要
                if (dp[j - coins[i]] != Integer.MAX_VALUE) {
                    dp[j] = Math.min(dp[j], dp[j - coins[i]] + 1);  // 取与不取
                }
            }
        }
        return  dp[amount] < Integer.MAX_VALUE ? dp[amount] : -1;
    }

    public static void main(String[] args) {
        int[] coins = new int[]{2};
        int amount = 3;
        int i = coinChange(coins, amount);
        System.out.println(i);
        System.out.println(Integer.MAX_VALUE);
        System.out.println(Integer.MAX_VALUE + 1);
    }
}
