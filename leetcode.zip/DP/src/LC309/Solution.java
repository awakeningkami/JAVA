package LC309;

import java.util.Arrays;

/*
给定一个整数数组prices，其中第 prices[i] 表示第 i 天的股票价格 。
设计一个算法计算出最大利润。在满足以下约束条件下，你可以尽可能地完成更多的交易（多次买卖一支股票）:
卖出股票后，你无法在第二天买入股票 (即冷冻期为 1 天)。
注意：你不能同时参与多笔交易（你必须在再次购买前出售掉之前的股票）。
 */
class Solution {
    public static int maxProfit(int[] prices) {
        if (prices.length <= 1) {
            return 0;
        }
        // dp[i][0] : 第i天，不持有股票的最大收益
        // dp[i][1] : 第i天，持有股票的最大收益
        int[][] dp = new int[prices.length][2];
        dp[0][0] = 0;
        dp[0][1] = -prices[0];
        // 为啥要初始化第二天？因为后面的状态都和其前两天有关系
        dp[1][0] = Math.max(dp[0][0], dp[0][1] + prices[1]);
        dp[1][1] = Math.max(dp[0][1], -prices[1]);
        for (int i = 2; i < prices.length; i++) {
            // 第i天不持有股票 : 1. 第i-1天就不持有股票； 2. 第i天卖出股票
            dp[i][0] = Math.max(dp[i - 1][0], dp[i - 1][1] + prices[i]);
            // 第i天持有股票 : 1. 第i-1天就持有股票；
            // 2. 第i天买入股票，最大收益要加上之前所得 (只有第 i-2 天不持有，第i天才能买入)
            dp[i][1] = Math.max(dp[i - 1][1], dp[i - 2][0] - prices[i]);
        }
        for (int[] a : dp) {
            System.out.println(Arrays.toString(a));
        }
        return dp[prices.length - 1][0];
    }

    public static int maxProfit2(int[] prices) {
        if (prices.length <= 1) {
            return 0;
        }
        // dp[0][0] : 前1天，不持有股票的最大收益
        // dp[0][1] : 前1天，持有股票的最大收益
        // dp[1][0] : 不持有股票的最大收益
        // dp[1][1] : 持有股票的最大收益
        int[][] dp = new int[2][2];
        dp[0][0] = 0;
        dp[0][1] = -prices[0];
        dp[1][0] = Math.max(dp[0][0], dp[0][1] + prices[1]);
        dp[1][1] = Math.max(dp[0][1], -prices[1]);
        System.out.println(Arrays.toString(dp[0]));
        System.out.println(Arrays.toString(dp[1]));
        for (int i = 2; i < prices.length; i++) {
            // 因为 dp[1]会改变, 所以提前记录下 dp[1]
            // 不能直接 int[] temp = dp[1];  因为右边为地址值
            int[] temp = new int[]{dp[1][0], dp[1][1]};
            dp[1][0] = Math.max(dp[1][0], dp[1][1] + prices[i]);
            dp[1][1] = Math.max(dp[1][1], dp[0][0] - prices[i]);
            // dp[0] 记录的就是 前前 的状态
            dp[0] = temp;
            System.out.print(i + ": ");
            System.out.println(Arrays.toString(dp[1]));
        }
        return dp[1][0];
    }

    public static void main(String[] args) {
        int[] prices = new int[]{1,2,3,0,2};
        int maxProfit = maxProfit(prices);
        System.out.println(maxProfit);
        System.out.println("*************");
        int maxProfit2 = maxProfit2(prices);
        System.out.println(maxProfit2);
    }
}
