package LC343;

/*
给定一个正整数 n ，将其拆分为 k 个 正整数 的和（ k >= 2 ），并使这些整数的乘积最大化。

返回 你可以获得的最大乘积 。
 */
class Solution {
    public int integerBreak(int n) {
        // dp[i] : 分拆数字i，可以得到的最大乘积为dp[i]
        int[] dp = new int[n + 1];
        dp[2] = 1;
        for (int i = 3; i <= n; i++) {
            for (int j = 1; j < i - 1; j++) {   // 因为 dp[0] dp[1]无意义，所以终止条件为 j < i - 1
                /*
                假设对正整数 i 拆分出的第一个正整数是 j（1 <= j < i），则有以下两种方案：
                1) 将 i 拆分成 j 和 i−j 的和，且 i−j 不再拆分成多个正整数，此时的乘积是 j * (i-j)
                2) 将 i 拆分成 j 和 i−j 的和，且 i−j 继续拆分成多个正整数，此时的乘积是 j * dp[i-j]
                 */
                dp[i] = Math.max(dp[i], Math.max(j * (i - j), j * dp[i - j]));
            }
        }
        return dp[n];
    }
}
