package LC121;

/*
给定一个数组 prices ，它的第 i 个元素 prices[i] 表示一支给定股票第 i 天的价格。
你只能选择 某一天 买入这只股票，并选择在 未来的某一个不同的日子 卖出该股票。
设计一个算法来计算你所能获取的最大利润。

返回你可以从这笔交易中获取的最大利润。如果你不能获取任何利润，返回 0 。

 */

import java.util.Arrays;

class Solution {
    public static int maxProfit(int[] prices) {
        // dp[i][0] : 第i天持有股票的最大收益
        // dp[i][1] : 第i天不持有股票的最大收益
        int[][] dp = new int[prices.length][2];
        dp[0][0] = -prices[0];
        dp[0][1] = 0;
        for (int i = 1; i < prices.length; i++) {
            // 第i天持有股票 : 1. 第i-1天就持有股票; 2. 第i天买入股票
            dp[i][0] = Math.max(dp[i - 1][0], -prices[i]);
            // 第i天不持有股票 : 1. 第i-1天就不持有股票； 2. 第i天卖出股票
            dp[i][1] = Math.max(dp[i - 1][1], dp[i - 1][0] + prices[i]);
        }
        for (int[] a : dp) {
            System.out.println(Arrays.toString(a));
        }
        // 买了的话，把股票卖出去肯定收益最大啦
        return dp[prices.length - 1][1];
    }

    public static int maxProfit2(int[] prices) {
        // dp[0] : 持有股票的最大收益
        // dp[1] : 不持有股票的最大收益
        int[] dp = new int[2];
        dp[0] = -prices[0];
        dp[1] = 0;
        for (int i = 1; i < prices.length; i++) {
            dp[0] = Math.max(dp[0], -prices[i]);
            dp[1] = Math.max(dp[1], dp[0] + prices[i]);

            System.out.println(Arrays.toString(dp));
        }
        return dp[1];
    }

    public static void main(String[] args) {
        int[] prices = new int[]{7,1,5,3,6,4};
        int maxProfit = maxProfit(prices);
        System.out.println(maxProfit);
        System.out.println("*****");
        int maxProfit2 = maxProfit2(prices);
        System.out.println(maxProfit2);
    }
}
