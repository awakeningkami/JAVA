package bagMulti;

import java.util.Arrays;

public class Solution {
    public static int maxValue(int[] weight, int[] value, int[] nums, int bagWeight) {
        // dp[j] ： 背包容量为 j 时 的最大总价值
        int[] dp = new int[bagWeight + 1];
        for (int i = 0; i < weight.length; i++) {
            for (int j = bagWeight; j >= weight[i]; j--) {
                for (int k = 1; k <= nums[i] && j >= k * weight[i]; k++) {
                    dp[j] = Math.max(dp[j], dp[j - k * weight[i]] + k * value[i]);
                }
            }
            System.out.println(Arrays.toString(dp));
        }
        return dp[bagWeight];
    }

    public static void main(String[] args) {
        int[] weight = new int[] {1, 3, 4};
        int[] value = new int[] {15, 20, 30};
        int[] nums = new int[] {2, 3, 2};
        int bagWeight = 10;
        int maxValue = maxValue(weight, value, nums, bagWeight);
        System.out.println(maxValue);
    }
}
