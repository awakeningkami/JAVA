package offer1049;

// 01背包
class Solution {
    public static int lastStoneWeightII(int[] stones) {
        int sum = 0;
        for (int stone : stones) {
            sum += stone;
        }
        int target = sum >> 1;
//        int target = sum / 2;
        // dp[j] 背包容量为 j 时，最大的总重量为 dp[j]
        int[] dp = new int[target + 1];
        for (int i = 0; i < stones.length; i++) {
            for (int j = target; j >= stones[i]; j--) {
                dp[j] = Math.max(dp[j], dp[j - stones[i]] + stones[i]);
            }

            for (int j = 0; j <= target; j++) {
                System.out.print(dp[j] + " ");
            }
            System.out.println();
        }
        return sum - dp[target] - dp[target];
    }

    public static int lastStoneWeightII2(int[] stones) {
        int sum = 0;
        for (int stone : stones) {
            sum += stone;
        }
        int target = sum / 2;
        // dp[i][j] 从下标 0~i 的石头中随便选取，背包容量为j时的最大总重量
        int[][] dp = new int[stones.length][target + 1];
        for (int j = stones[0]; j <= target; j++) {
            dp[0][j] = stones[0];
        }
        for (int i = 1; i < stones.length; i++) {
            for (int j = 1; j <= target; j++) {
                if (stones[i] > j) {
                    dp[i][j] = dp[i - 1][j];
                } else {
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i - 1][j - stones[i]] + stones[i]);
                }
            }
        }

        for (int i = 0; i < stones.length; i++) {
            for (int j = 0; j <= target; j++) {
                System.out.print(dp[i][j] + " ");
            }
            System.out.println();
        }
        return sum - 2 * dp[stones.length -1][target];
    }

    public static void main(String[] args) {
        int[] stones = new int[]{2,4,1,1};
        int i = lastStoneWeightII(stones);
        System.out.println(i);
        System.out.println("*******");
        int i1 = lastStoneWeightII2(stones);
        System.out.println(i1);
    }
}