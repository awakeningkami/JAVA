package LC647;

import java.util.Arrays;

/*
给你一个字符串 s ，请你统计并返回这个字符串中 回文子串 的数目。
回文字符串 是正着读和倒过来读一样的字符串。
子字符串 是字符串中的由连续字符组成的一个序列。
具有不同开始位置或结束位置的子串，即使是由相同的字符组成，也会被视作不同的子串。

 */
// 回文串相关的首先要解决判断是不是回文串（dp和中心扩散法），然后再计算
// LC5
class Solution {
    public static int countSubstrings(String s) {
        // dp[i][j]: 下标为i~j的子串是否为回文串，是dp[i][j] = true; 否dp[i][j] = false
        boolean[][] dp = new boolean[s.length()][s.length()];
        int len = s.length(), res = 0;
        for (int i = len - 1; i >= 0; i--) {
            for (int j = i; j < len; j++) {
                if (s.charAt(i) == s.charAt(j)) {
                    if (j - i <= 1) {
                        dp[i][j] = true;
                        res += 1;
                    } else if (dp[i + 1][j - 1]) {
                        dp[i][j] = true;
                        res += 1;
                    }
                }
            }
        }
        for (boolean[] a : dp) {
            System.out.println(Arrays.toString(a));
        }
        return res;
    }

    // 中心扩散法
    public static int countSubstrings2(String s) {
        int res = 0;
        for (int i = 0; i < s.length(); i++) {
            // 一个字符为中心
            res += countPalindrome(s, i, i);
            // 两个字符为中心
            res += countPalindrome(s, i, i + 1);
        }
        return res;
    }

    private static int countPalindrome(String s, int left, int right) {
        int subRes = 0;
        while (left >= 0 && right < s.length() && s.charAt(left) == s.charAt(right)) {
            left--;
            right++;
            subRes++;
        }
        return subRes;
    }


    public static void main(String[] args) {
        String s = "aaa";
        int i = countSubstrings(s);
        System.out.println(i);
    }
}
