package LC583;

import java.util.Arrays;

/*
给定两个单词 word1 和 word2 ，返回使得 word1 和  word2 相同所需的最小步数。
每步 可以删除任意一个字符串中的一个字符。
 */
class Solution {
    public static int minDistance(String word1, String word2) {
        // dp[i][j] 下标 0~i-1 的 word1 和下标为 0~j-1 的word2相同要删除的最少次数为 dp[i][j]
        int[][] dp = new int[word1.length() + 1][word2.length() + 1];
        for (int i = 0; i <= word1.length(); i++) {
            dp[i][0] = i;
        }
        for (int j = 0; j <= word2.length(); j++) {
            dp[0][j] = j;
        }

        for (int i = 1; i <= word1.length(); i++) {
            for (int j = 1; j <= word2.length(); j++) {
                if (word1.charAt(i - 1) == word2.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    dp[i][j] = Math.min(Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1), dp[i - 1][j - 1] + 2);
                }
            }
        }
        for (int[] a : dp) {
            System.out.println(Arrays.toString(a));
        }
        return dp[word1.length()][word2.length()];
    }

    // 最长公共子序列 LC1143
    public static int minDistance2(String word1, String word2) {
        // dp[i][j] : 下标为 0~i-1 的word1与下标为 0~j-1 的word2的最长公共子序列的长度为dp[i][j]
        int[][] dp = new int[word1.length() + 1][word2.length() + 1];
        for (int i = 1; i <= word1.length(); i++) {
            for (int j = 1; j <= word2.length(); j++) {
                if (word1.charAt(i - 1) == word2.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1] + 1;
                } else {
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
                }
            }
        }
        return word1.length() + word2.length() - dp[word1.length()][word2.length()];
    }

    public static void main(String[] args) {
        String word1 = "sea";
        String word2 = "eat";
        int i = minDistance(word1, word2);
        System.out.println(i);
    }
}
