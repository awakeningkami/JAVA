package LC392;
/*
给定字符串 s 和 t ，判断 s 是否为 t 的子序列。
字符串的一个子序列是原始字符串删除一些（也可以不删除）字符而不改变剩余字符相对位置形成的新字符串。
 */

import java.util.Arrays;

class Solution {
    // dp  see LC1143 唯一不同的就是 s 必须取
    public static boolean isSubsequence(String s, String t) {
        // dp[i][j] 下标为 0~i-1 的 s 与下标为 0~j-1 的 t 最长公共子序列的长度为dp[i][j]
        int[][] dp = new int[s.length() + 1][t.length() + 1];
        for (int i = 1; i <= s.length(); i++) {
            for (int j = 1; j <= t.length(); j++) {
                if (s.charAt(i - 1) == t.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1] + 1;
                } else {
                    dp[i][j] = dp[i][j - 1];
                }
            }
        }
        for (int[] a : dp) {
            System.out.println(Arrays.toString(a));
        }
        return dp[s.length()][t.length()] == s.length();
    }

    // 双指针
    public static boolean isSubsequence2(String s, String t) {
        int j = 0;
        for (int i = 0; i < t.length() && j < s.length(); i++) {
            if (t.charAt(i) == s.charAt(j)) {
                j++;
            }
        }
        return j == s.length();
    }

    public static void main(String[] args) {
        String t = "ahbgdc";
        String s = "abc";
        boolean b = isSubsequence2(s, t);
        System.out.println(b);
    }
}
