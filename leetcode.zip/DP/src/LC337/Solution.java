package LC337;

import java.util.Arrays;

/*
小偷又发现了一个新的可行窃的地区。这个地区只有一个入口，我们称之为root。
除了root之外，每栋房子有且只有一个“父“房子与之相连。
一番侦察之后，聪明的小偷意识到“这个地方的所有房屋的排列类似于一棵二叉树”。
如果 两个直接相连的房子在同一天晚上被打劫 ，房屋将自动报警。
给定二叉树的root。返回在不触动警报的情况下，小偷能够盗取的最高金额。
 */
class Solution {
    public int rob(TreeNode root) {
        int[] res = robTree(root);
        return Math.max(res[0], res[1]);
    }

    private static int[] robTree(TreeNode root) {
        // dp[] : dp[0],不偷当前节点的最高金额; dp[1], 偷当前节点的最高金额
        int[] dp = new int[2];
        if (root == null) {
            return dp;
        }
        // 树的后续遍历
        int[] left = robTree(root.left);
        int[] right = robTree(root.right);
        // 如果不偷当前节点，那么左右孩子就可以偷，至于到底偷不偷一定是选一个最大的
        dp[0] = Math.max(left[0], left[1]) + Math.max(right[0], right[1]);
        // 如果是偷当前节点，那么左右孩子就不能偷
        dp[1] = left[0] + right[0] + root.val;
        return dp;
    }

    public static void main(String[] args) {
        TreeNode tree1 = new TreeNode(3);
        TreeNode tree21 = new TreeNode(2);
        TreeNode tree22 = new TreeNode(3);
        TreeNode tree31 = new TreeNode(3);
        TreeNode tree32 = new TreeNode(1);
        tree1.left = tree21;
        tree1.right = tree22;
        tree21.right = tree31;
        tree22.right = tree32;

        int[] ints = robTree(tree1);
        System.out.println(Arrays.toString(ints));
    }
}