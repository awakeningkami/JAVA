package LC718;

/*
给两个整数数组 nums1 和 nums2 ，
返回 两个数组中 公共的 、长度最长的子数组的长度。
 */

import java.util.Arrays;

class Solution {
    public static int findLength(int[] nums1, int[] nums2) {
        // dp[i][j] : 以下标 i 结尾的A 和 以下标 j 结尾的B的最长子数组的长度
        int[][] dp = new int[nums1.length][nums2.length];
        int res = 0;
        for (int j = 0; j < nums2.length; j++) {
            if (nums2[j] == nums1[0]) {
                dp[0][j] = 1;
            }
            res = Math.max(res, dp[0][j]);
        }
        for (int i = 0; i < nums1.length; i++) {
            if (nums1[i] == nums2[0]) {
                dp[i][0] = 1;
            }
            res = Math.max(res, dp[i][0]);
        }
        for (int i = 1; i < nums1.length; i++) {
            for (int j = 1; j < nums2.length; j++) {
                if (nums1[i] == nums2[j]) {
                    dp[i][j] = dp[i - 1][j - 1] + 1;
                }
                res = Math.max(res, dp[i][j]);
            }
        }

        for (int[] a : dp) {
            System.out.println(Arrays.toString(a));
        }
        return res;
    }

    public static int findLength2(int[] nums1, int[] nums2) {
        // dp[i][j] : 以下标 i-1 结尾的A 和 以下标 j-1 结尾的B的最长子数组的长度
        int[][] dp = new int[nums1.length + 1][nums2.length + 1];
        int res = 0;
        for (int i = 1; i <= nums1.length; i++) {
            for (int j = 1; j <= nums2.length; j++) {
                if (nums1[i - 1] == nums2[j - 1]) {
                    dp[i][j] = dp[i - 1][j - 1] + 1;
                }
                res = Math.max(res, dp[i][j]);
            }
        }

        for (int[] a : dp) {
            System.out.println(Arrays.toString(a));
        }
        return res;
    }

    public static int findLength3(int[] nums1, int[] nums2) {
        // dp[j] : 以下标 j-1 结尾的B的最长子数组的长度
        int[] dp = new int[nums2.length + 1];
        int res = 0;
        for (int i = 1; i <= nums1.length; i++) {
            for (int j = nums2.length; j >= 1; j--) {
                if (nums1[i - 1] == nums2[j - 1]) {
                    dp[j] = dp[j - 1] + 1;
                } else {
                    dp[j] = 0; // 注意这里不相等的时候要赋0
                }
                res = Math.max(res, dp[j]);
            }
            System.out.println(Arrays.toString(dp));
        }
        return res;
    }

    public static void main(String[] args) {
        int[] nums2 = new int[]{1, 2, 3, 2, 1};
        int[] nums1 = new int[]{3, 2, 1, 4, 7};
        int length = findLength2(nums1, nums2);
        System.out.println(length);
        System.out.println("*************");
        int length3 = findLength3(nums1, nums2);
        System.out.println(length3);
    }
}