package LC139;

/*
给你一个字符串 s 和一个字符串列表 wordDict 作为字典。请你判断是否可以利用字典中出现的单词拼接出 s 。
注意：不要求字典中出现的单词全部都使用，并且字典中的单词可以重复使用。
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// 完全背包
class Solution {
    public static boolean wordBreak(String s, List<String> wordDict) {
        // dp[i] 字符串长度为 i 是否能拼接出来
        boolean[] dp = new boolean[s.length() + 1];
        dp[0] = true;

        for (int i =1; i <= s.length(); i++) {
            for (int j = 0; j < wordDict.size(); j++) {
                String word = wordDict.get(j);
                if (i >= word.length()){
                    dp[i] = dp[i - word.length()] && word.equals(s.substring(i - word.length(), i)) || dp[i];
                }
            }
        }
        return dp[s.length()];
    }
    public static void main(String[] args) {
        String s = "applepenapple";
        String[] arr = new String[]{"apple","pen"};
        List<String> wordDict = Arrays.asList(arr);
        boolean b = wordBreak(s, wordDict);
        System.out.println(b);
    }
}