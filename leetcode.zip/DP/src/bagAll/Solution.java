package bagAll;

/*
完全背包问题
 */
public class Solution {
    public static int maxValue(int[] weight, int[] value, int bagWeight) {
        int[] dp = new int[bagWeight + 1];
        for (int i = 0; i < weight.length; i++) {
            for (int j = weight[i]; j <= bagWeight; j++) {
                dp[j] = Math.max(dp[j], dp[j - weight[i]] + value[i]);
            }
            for (int j = 0; j <= bagWeight; j++) {
                System.out.print(dp[j] + " ");
            }
            System.out.println();
        }
        return dp[bagWeight];
    }

    public static int maxValue2(int[] weight, int[] value, int bagWeight) {
        int[] dp = new int[bagWeight + 1];
        for (int i = 1; i <= bagWeight; i++) {
            for (int j = 0; j < weight.length; j++) {
                if (i >= weight[j]) {
                    dp[i] = Math.max(dp[i], dp[i - weight[j]] + value[j]);
                }
            }
            for (int j = 0; j <= bagWeight; j++) {
                System.out.print(dp[j] + " ");
            }
            System.out.println();
        }
        return dp[bagWeight];
    }

    public static void main(String[] args) {
        int[] weight = new int[]{2, 3, 4};
        int[] value = {15, 20, 30};
        int bagWeight = 4;
        int maxValue = maxValue(weight, value, bagWeight);
        System.out.println(maxValue);

        int maxValue2 = maxValue2(weight, value, bagWeight);
        System.out.println(maxValue2);
    }
}
