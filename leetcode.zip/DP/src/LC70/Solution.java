package LC70;

/*
假设你正在爬楼梯。需要 n 阶你才能到达楼顶。
每次你可以爬 1 或 2 个台阶。你有多少种不同的方法可以爬到楼顶呢？
 */
class Solution {
    public int climbStairs(int n) {
        if (n <= 1) {
            return n;
        }
        // dp[i] 爬到第i层楼梯，有dp[i]种方法
        int[] dp = new int[n + 1];
        dp[1] = 1;
        dp[2] = 2;
        for (int i = 3; i <= n; i++) {
            dp[n] = dp[n - 1] + dp[n - 2];
        }
        return dp[n];
    }

    public int climbStairs1(int n) {
        if (n <= 2) {
            return n;
        }
        int a = 1, b = 2, res = 0;
        for (int i = 3; i <= n; i++) {
            res = a + b;
            a = b;
            b = res;
        }
        return res;
    }

    // 完全背包
    public int climbStairs3(int n) {
        // dp[i] ：爬到第i层楼梯，有dp[i]种方法
        int[] dp = new int[n + 1];
        dp[0] = 1;
        int[] nums = new int[]{1, 2};
        for (int i = 1; i <= n; i++) {
            for (int j = 0; j < nums.length; j++) {
                if (i >= nums[j]) {
                    dp[i] += dp[i - nums[j]];
                }
            }
        }
        return dp[n];
    }
}
