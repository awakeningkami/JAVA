package LC494;

// 01背包
class Solution {
    public static int findTargetSumWays(int[] nums, int target) {
        int sum = 0;
        for (int num : nums) {
            sum += num;
        }
        // positive - (sum - positive) = target  -> pos = (sum + target) / 2
        if (Math.abs(target) > sum || (sum + target) % 2 != 0) {
            return 0;
        }
        int bagSize = (sum + target) / 2;
        // dp[i][j] 从下标 0~i 任意选取，总和为 j 的方案数为 dp[i][j]
        int[][] dp = new int[nums.length][bagSize + 1];
        dp[0][0] = 1;
        // 相比于其它 01 背包问题，这里只能从 j = 0 开始，因为dp[0][0]没有初始化完
        for (int j = 0; j <= bagSize; j++) {
            if (j == nums[0]) {
                // 注意这里，如果 j = 0, num[0] = 0;  此时dp[0][0] = 2;
                // 因为放和不放 num[0], 共两种方案
                dp[0][j] += 1;
                break;
            }
        }

        for (int i = 1; i < nums.length; i++) {
            for (int j = 0; j <= bagSize; j++) {
                if (j < nums[i]) {
                    dp[i][j] = dp[i - 1][j];
                } else {
                    dp[i][j] = dp[i - 1][j] + dp[i - 1][j - nums[i]];
                }
            }
        }
        for (int i = 0; i < nums.length; i++) {
            for (int j = 0; j <= bagSize; j++) {
                System.out.print(dp[i][j] + " ");
            }
            System.out.println();
        }
        return dp[nums.length - 1][bagSize];
    }

    public static int findTargetSumWays2(int[] nums, int target) {
        int sum = 0;
        for (int num : nums) {
            sum += num;
        }
        // positive - (sum - positive) = target  -> pos = (sum + target) / 2
        if (Math.abs(target) > sum || (sum + target) % 2 != 0) {
            return 0;
        }
        int bagSize = (sum + target) / 2;
        // dp[j]  装满容量为 j 的包，有dp[j]中方案
        int[] dp = new int[bagSize + 1];
        dp[0] = 1;  // 开始我啥都不要，即我本来就有一种方案
        for (int i = 0; i < nums.length; i++) {
            for (int j = bagSize; j >= nums[i]; j--) {
                /*
                不考虑nums[i]的情况下，填满容量为j - nums[i]的背包，有dp[j - nums[i]]种方法。
                那么只要搞到nums[i]的话，凑成dp[j]就有dp[j - nums[i]] 种方法。
                 */
                dp[j] += dp[j - nums[i]];
            }
            for (int j = 0; j <= bagSize; j++) {
                System.out.print(dp[j] + " ");
            }
            System.out.println();
        }
        return dp[bagSize];
    }

    public static void main(String[] args) {
        int[] nums = new int[]{0,0,0,0,0,0,0,0,1};
        int target = 1;

        int targetSumWays = findTargetSumWays(nums, target);
        System.out.println(targetSumWays);
        System.out.println("*********");
        int targetSumWays2 = findTargetSumWays2(nums, target);
        System.out.println(targetSumWays2);
    }
}
