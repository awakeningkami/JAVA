package LC122;

/*
给定一个数组 prices ，其中 prices[i] 表示股票第 i 天的价格。
在每一天，你可能会决定购买和/或出售股票。你在任何时候最多只能持有 一股 股票。
你也可以购买它，然后在 同一天 出售。
返回 你能获得的 最大 利润。
 */
class Solution {
    public int maxProfit(int[] prices) {
        // dp[i][0] : 第i天持有股票的最大收益
        // dp[i][1] : 第i天不持有股票的最大收益
        int[][] dp = new int[prices.length][2];
        dp[0][0] = -prices[0];
        dp[0][1] = 0;
        for (int i = 1; i < prices.length; i++) {
            // 第i天持有股票 : 1. 第i-1天就持有股票; 2. 第i天买入股票 (利润要加上之前所得)
            dp[i][0] = Math.max(dp[i - 1][0], dp[i - 1][1] - prices[i]);
            // 第i天不持有股票 : 1. 第i-1天就不持有股票； 2. 第i天卖出股票
            dp[i][1] = Math.max(dp[i - 1][1], dp[i- 1][0] + prices[i]);
        }
        return dp[prices.length - 1][1];
    }

    public int maxProfit2(int[] prices) {
        // [0] : 不有股票的最大收益
        // [1] : 持有股票的最大收益
        int[] dp = new int[2];
        // dp[0] = 0;
        dp[1] = -prices[0];
        for (int i = 1; i < prices.length; i++) {
            dp[0] = Math.max(dp[0], dp[1] + prices[i]);
            dp[1] = Math.max(dp[1], dp[0] - prices[i]);
        }
        return dp[0];
    }

    public static void main(String[] args) {

    }
}
