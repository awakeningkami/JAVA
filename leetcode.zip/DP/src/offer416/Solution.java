package offer416;

/*
给你一个只包含正整数的非空数组 nums 。
请你判断是否可以将这个数组分割成两个子集，使得两个子集的元素和相等。
 */

// 01背包
class Solution {
    public static boolean canPartition(int[] nums) {
        int sum = 0;
        for (int num : nums) {
            sum += num;
        }
        if (sum % 2 != 0) {
            return false;
        }
        int target = sum / 2;
        // dp[j] : 背包总容量是j，最大可以凑成j的子集总和为dp[j]。
        int[] dp = new int[target + 1];
        for (int i = 0; i < nums.length; i++) {
            for (int j = target; j >= nums[i]; j--) {
                dp[j] = Math.max(dp[j], dp[j - nums[i]] + nums[i]);
            }

            for (int j = 0; j <= target; j++) {
                System.out.print(dp[j] + " ");
            }
            System.out.println();
        }
        return dp[target] == target;
    }

    public static boolean canPartition2(int[] nums) {
        int sum = 0;
        for (int num : nums) {
            sum += num;
        }
        if (sum % 2 != 0) {
            return false;
        }
        int target = sum / 2;
        // dp[i][j]  从下标 0~i 中任意选取，最大可以凑成 j 的子集总和为 dp[i][j]
        int[][] dp = new int[nums.length][target + 1];
        for (int j = nums[0]; j <= target; j++) {
            dp[0][j] = nums[0];
        }
        for (int i = 1; i < nums.length; i++) {
            for (int j = 1; j <= target; j++) {
                if (j < nums[i]) {
                    dp[i][j] = dp[i - 1][j];
                } else {
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i - 1][j - nums[i]] + nums[i]);
                }
            }
        }
        for (int i = 0; i < nums.length; i++) {
            for (int j = 0; j <= target; j++) {
                System.out.print(dp[i][j] + " ");
            }
            System.out.println();
        }

        return dp[nums.length - 1][target] == target;
    }

    public static void main(String[] args) {
        int[] nums = new int[]{1,5,11,5};
        boolean b = canPartition(nums);
        System.out.println(b);
        System.out.println("*****************");
        boolean b1 = canPartition2(nums);
        System.out.println(b1);
    }
}
