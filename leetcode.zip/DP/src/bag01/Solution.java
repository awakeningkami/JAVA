package bag01;

import java.util.Arrays;

/*
01背包问题
 */
public class Solution {
    public static int maxValue(int[] weight, int[] value, int bagWeight) {
        // dp[i][j] : 从下标0~i的物品中任意选取，背包容量为 j 时，最大总价值
        int m = value.length, n = bagWeight + 1;
        int[][] dp = new int[m][n];
        for (int j = weight[0]; j < n; j++) {
            dp[0][j] = value[0];
        }
        for (int i = 1; i < m; i++) {
            for (int j = 1; j < n; j++) {
                if (weight[i] > j) {
                    dp[i][j] = dp[i - 1][j];
                } else {
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i - 1][j - weight[i]] + value[i]);
                }
            }
        }
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(dp[i][j] + " ");
            }
            System.out.println();
        }
        return dp[m - 1][n - 1];
    }

    public static void main(String[] args) {
        int[] weight = new int[]{1, 3, 4};
        int[] value = {15, 20, 30};
        int bagWeight = 4;
        int maxValue = maxValue(weight, value, bagWeight);
        System.out.println(maxValue);
        System.out.println("****************");
        int maxValue2 = maxValue2(weight, value, bagWeight);
        System.out.println(maxValue2);

    }
    public static int maxValue2(int[] weight, int[] value, int bagWeight) {
        /*
        为什么二维dp可以降为一维dp？
        二维dp的转移方程 ：dp[i][j] = max(dp[i - 1][j], dp[i - 1][j - weight[i]] + value[i])
        可以发现，当前行都是根据上一行推导出来的，为什么不直接覆盖？ （滚动数组）
         */

        // dp[j] ： 背包容量为 j 时 的最大总价值
        // 转移方程 ： dp[j] = max(dp[j], dp[j - weight[i]] + value[i])  即取i和不取i
        // 初始化 : dp[0] = 0,  其它因为会取max，初始化为0不会影响结果, 而不是被初始值覆盖了
        int[] dp = new int[bagWeight + 1];
        for (int i = 0; i < weight.length; i++) {
            for (int j = bagWeight; j >= weight[i]; j--) {
                dp[j] = Math.max(dp[j], dp[j - weight[i]] + value[i]);
            }
            System.out.println(Arrays.toString(dp));
        }
        return dp[bagWeight];
    }
}
