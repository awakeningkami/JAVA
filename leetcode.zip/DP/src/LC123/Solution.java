package LC123;

import java.util.Arrays;

/*
给定一个数组，它的第 i 个元素是一支给定的股票在第 i 天的价格。
设计一个算法来计算你所能获取的最大利润。你最多可以完成两笔交易。
注意：你不能同时参与多笔交易（你必须在再次购买前出售掉之前的股票）。
 */
class Solution {
    public static int maxProfit(int[] prices) {
        // dp[i][0] : 第i天，第一次持有股票的最大收益
        // dp[i][1] : 第i天，第一次不持有股票的最大收益
        // dp[i][2] : 第i天，第二次持有股票的最大收益
        // dp[i][3] : 第i天，第二次不持有股票的最大收益
        int[][] dp = new int[prices.length][4];
        dp[0][0] = -prices[0];
        dp[0][1] = 0;
        // notice ：假如数组长度不够买卖两次，为了不失一般性，我们允许这时候可以卖出后再次买入
        // 并不会影响结果
        dp[0][2] = -prices[0];
        dp[0][3] = 0;
        for (int i = 1; i < prices.length; i++) {
            dp[i][0] = Math.max(dp[i - 1][0], -prices[i]);
            dp[i][1] = Math.max(dp[i - 1][1], dp[i - 1][0] + prices[i]);
            dp[i][2] = Math.max(dp[i - 1][2], dp[i - 1][1] - prices[i]);
            dp[i][3] = Math.max(dp[i - 1][3], dp[i - 1][2] + prices[i]);
        }
        for (int[] a :dp) {
            System.out.println(Arrays.toString(a));
        }
        return dp[prices.length - 1][3];
    }
    public static int maxProfit2(int[] prices){
        // dp[0] : 第一次持有股票的最大收益
        // dp[1] : 第一次不持有股票的最大收益
        // dp[2] : 第二次持有股票的最大收益
        // dp[3] : 第二次不持有股票的最大收益
        int[] dp = new int[4];
        dp[0] = -prices[0];
        dp[1] = 0;
        dp[2] = -prices[0];
        dp[3] = 0;
        for (int i = 1; i < prices.length; i++) {
            dp[0] = Math.max(dp[0], -prices[i]);
            dp[1] = Math.max(dp[1], dp[0] + prices[i]);
            dp[2] = Math.max(dp[2], dp[1] - prices[i]);
            dp[3] = Math.max(dp[3], dp[2] + prices[i]);
        }
        return dp[3];
    }


    public static void main(String[] args) {
        int[] prices = new int[]{1,2,3,4,5};
        int maxProfit = maxProfit(prices);
        System.out.println(maxProfit);
    }
}
