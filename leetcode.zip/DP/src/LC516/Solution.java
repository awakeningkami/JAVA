package LC516;
/*
给你一个字符串 s ，找出其中最长的回文子序列，并返回该序列的长度。
子序列定义为：不改变剩余字符顺序的情况下，删除某些字符或者不删除任何字符形成的一个序列。
 */

import java.util.Arrays;

// LC5为最长回文子串，此题为最长回文子序列
class Solution {
    public static int longestPalindromeSubseq(String s) {
        // dp[i][j] 下标为i~j的最长回文子序列为 dp[i][j]
        int[][] dp = new int[s.length()][s.length()];
        int len = s.length();
        for (int i = len - 1; i >= 0; i--) {
            for (int j = i; j < len; j++) {
                if (s.charAt(i) == s.charAt(j)) {
                    if (j - i == 0) {
                        dp[i][j] = 1;
                    } else if (j - i == 1) { // 此情况可以省略，eg dp[1][2] = dp[2][1] + 2, 而 dp[2][1]初始化为0
                        dp[i][j] = 2;
                    } else {
                        dp[i][j] = dp[i + 1][j - 1] + 2;
                    }
                } else {
                    dp[i][j] = Math.max(dp[i + 1][j], dp[i][j - 1]);
                }
            }
        }
        for (int[] a : dp) {
            System.out.println(Arrays.toString(a));
        }
        return dp[0][len - 1];
    }

    public static void main(String[] args) {
        String s = "cbbd";
        int i = longestPalindromeSubseq(s);
        System.out.println(i);
    }
}
