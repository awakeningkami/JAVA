package LC72;

import java.util.Arrays;

/*
给你两个单词 word1 和 word2，请返回将 word1 转换成 word2 所使用的最少操作数。

你可以对一个单词进行如下三种操作：
插入一个字符
删除一个字符
替换一个字符

 */
class Solution {
    public static int minDistance(String word1, String word2) {
        // dp[i][j] 下标 0~i-1 的 word1，下标 0~j-1 的 word2的最少操作数为 dp[i][j]
        int[][] dp = new int[word1.length() + 1][word2.length() + 1];
        for (int i = 0; i <= word1.length(); i++) {
            dp[i][0] = i;
        }
        for (int j =0; j <= word2.length(); j++) {
            dp[0][j] = j;
        }
        for (int i =1; i <= word1.length(); i++) {
            for (int j =1; j <= word2.length(); j++) {
                if (word1.charAt(i - 1) == word2.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    // word1删除一个元素, 相当于word2添加一个元素
                    // 三种情况: word1删除（word2插入）、word1插入（word2删除）、word1修改（word2修改）
                    dp[i][j] = Math.min(Math.min(dp[i - 1][j], dp[i][j - 1]), dp[i - 1][j - 1]) + 1;
                }
            }
        }
        for (int[] a : dp) {
            System.out.println(Arrays.toString(a));
        }
        return dp[word1.length()][word2.length()];
    }

    public static void main(String[] args) {
        String word1 = "horse";
        String word2 = "ros";
        int i = minDistance(word1, word2);
        System.out.println(i);
    }
}
