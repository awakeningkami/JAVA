package LC115;

import java.util.Arrays;

/*
给定一个字符串 s 和一个字符串 t ，计算在 s 的子序列中 t 出现的个数。

字符串的一个 子序列 是指，通过删除一些（也可以不删除）字符且不干扰剩余字符相对位置所组成的新字符串。
（例如，"ACE" 是 "ABCDE" 的一个子序列，而 "AEC" 不是）

s = "rabbbit", t = "rabbit"
s = "babgbag", t = "bag"
 */
class Solution {
    public static int numDistinct(String s, String t) {
        // dp[i][j] : 下标为 0~j-1 的 s 包含下标为 0~i-1 的 t 的个数为 dp[i][j]
        int[][] dp = new int[t.length() + 1][s.length() + 1];
        for (int j = 0; j <= s.length(); j++) {
            dp[0][j] = 1;
        }
        for (int i = 1; i <= t.length(); i++) {
            for (int j = 1; j <= s.length(); j++) {
                if (t.charAt(i - 1) == s.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1] + dp[i][j - 1];
                } else {
                    dp[i][j] = dp[i][j - 1];
                }
            }
        }
        for (int[] a : dp) {
            System.out.println(Arrays.toString(a));
        }
        return dp[t.length()][s.length()];
    }

    public static int numDistinct2(String s, String t) {
        // 滚动数组
        // dp[j]  下标 0~j-1的t在s子串的个数为 dp[j]
        int[] dp = new int[t.length() + 1];
        dp[0] = 1;
        for (int i = 1; i <= s.length(); i++) {
            for (int j = t.length(); j >=1; j--) {
                if (s.charAt(i - 1) == t.charAt(j - 1)) {
                    dp[j] += dp[j - 1];
                }
            }
            System.out.println(Arrays.toString(dp));
        }
        return dp[t.length()];
    }


    public static void main(String[] args) {

        String s = "baegg";
        String t = "bag";
        int i = numDistinct2(s, t);
        System.out.println(i);
    }
}
