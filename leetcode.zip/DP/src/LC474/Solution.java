package LC474;

class Solution {
    public static int findMaxForm(String[] strs, int m, int n) {
        // dp[i][j][k] : 从下标 0~i 字符串中任意选取，不超过j个0和k个1的字符串的最大数量
        int[][][] dp = new int[strs.length][m + 1][n + 1];
        int[] count = countZeroAndOne(strs[0]);
        int zeros = count[0], ones = count[1];
        for (int j = zeros; j <= m; j++) {
            for (int k = ones; k <= n; k++) {
                dp[0][j][k] = 1;
            }
        }

        for (int i = 1; i < strs.length; i++) {
            count = countZeroAndOne(strs[i]);
            zeros = count[0];
            ones = count[1];
            for (int j = 0; j <= m; j++) {
                for (int k = 0; k <= n; k++) {
                    if (zeros > j || ones > k) {
                        dp[i][j][k] = dp[i - 1][j][k];
                    } else {
                        dp[i][j][k] = Math.max(dp[i - 1][j][k], dp[i - 1][j - zeros][k - ones] + 1);
                    }
                }
            }
        }
        return dp[strs.length - 1][m][n];
    }

    public static int findMaxForm2(String[] strs, int m, int n) {
        // dp[j][k] : 不超过j个0和k个1的字符串的最大数量
        int[][] dp = new int[m + 1][n + 1];
        for (int i = 0; i < strs.length; i++) {
            int[] count = countZeroAndOne(strs[i]);
            int zeros = count[0];
            int ones = count[1];
            for (int j = m; j >= zeros; j--) {
                for (int k = n; k >= ones; k--){
                    dp[j][k] = Math.max(dp[j][k], dp[j - zeros][k - ones] + 1);
                }
            }
        }
        return dp[m][n];
    }


    private static int[] countZeroAndOne(String str) {
        int[] res = new int[2];
        for (char c : str.toCharArray()) {
            if (c == '0') {
                res[0]++;
            } else {
                res[1]++;
            }
        }
        return res;
    }
}