package LC206;

/*
给你单链表的头节点 head ，请你反转链表，并返回反转后的链表。
 */
public class Solution {
    public ListNode reverseList(ListNode head) {
        ListNode left = null;
        ListNode right = head;
        while (right != null) {
            ListNode temp = right.next;
            right.next = left;
            left = right;
            right = temp;
        }
        return left;
    }

    /*----------递归------------*/
    public ListNode reverseList2(ListNode head) {
        if (head == null) {
            return null;
        }
        return traverse(head);
    }
    private ListNode traverse(ListNode head) {
        if (head.next == null) {
            return head;
        }
        ListNode res = traverse(head.next);
        head.next.next = head;
        head.next = null;
        return res;
    }
}
