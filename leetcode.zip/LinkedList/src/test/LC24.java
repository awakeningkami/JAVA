package test;

public class LC24 {
    public ListNode swapPairs(ListNode head) {
        return traverse(head);
    }
    private ListNode traverse(ListNode head) {
        if (head == null || head.next == null) {
            return head;
        }
        ListNode temp = head.next;
        head.next = traverse(head.next);
        temp.next = head;
        return temp;
    }
}
