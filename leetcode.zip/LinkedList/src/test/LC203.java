package test;


public class LC203 {
    public ListNode removeElements2(ListNode head, int val) {
        return traverse(head, val);
    }
    ListNode traverse(ListNode head, int val) {
        if (head == null) {
            return null;
        }
        head.next = traverse(head.next, val);
        if (head.val == val) {
            return head.next;
        } else {
            return head;
        }
    }
}
