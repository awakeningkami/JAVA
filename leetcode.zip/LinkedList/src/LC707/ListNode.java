package LC707;

public class ListNode {
    int val;
    ListNode next;
    ListNode pre;
    ListNode() {}
    ListNode(int val) {
        this.val = val;
    }

}
