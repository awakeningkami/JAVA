package LC707;

public class MyDoubleLinkedList {
    int size;
    ListNode head;
    ListNode tail;

    public MyDoubleLinkedList() {
        size = 0;
        head = new ListNode(0);
        tail = new ListNode(0);
        head.next = tail;
        tail.pre = head;
    }

    public int get(int index) {
        if (index < 0 || index >= size) {
            return -1;
        }
        // size / 2，偶数的话右边多一个节点
        ListNode cur;
        if (index <= (size) / 2) {
            cur = head;
            while (index-- >= 0) {
                cur = cur.next;
            }
        } else {
            cur = tail;
            // size - 1 - index 即从后往前数的索引
            // 0 1 2 3
            // 3 2 1 0
            for (int i = 0; i <= size - 1 - index; i++) {
                cur = cur.pre;
            }
        }
        return cur.val;
    }

    public ListNode getNode(int index) {
        if (index <= 0) {
            return head.next;
        }
        if (index >= size) {
            return tail;
        }
        ListNode cur;
        if (index <= (size) / 2) {
            cur = head;
            while (index-- >= 0) {
                cur = cur.next;
            }
        } else {
            cur = tail;
            for (int i = 0; i <= size - 1 - index; i++) {
                cur = cur.pre;
            }
        }
        return cur;
    }

    public void addAtIndex(int index, int val) {
        if (index > size) {
            return;
        }
        if (index < 0) {
            index = 0;
        }
        ListNode cur = getNode(index);
        ListNode newNode = new ListNode(val);
        cur.pre.next = newNode;
        newNode.pre = cur.pre;
        newNode.next = cur;
        cur.pre = newNode;
        size++;
    }

    public void addAtHead(int val) {
        addAtIndex(0, val);
    }

    public void addAtTail(int val) {
        addAtIndex(size, val);
    }

    public void deleteAtIndex(int index) {
        if (index >= 0 && index < size) {
            ListNode cur = getNode(index);
            cur.next.pre = cur.pre;
            cur.pre.next = cur.next;
            size--;
        }
    }
}
