package LC19;

/*
给你一个链表，删除链表的倒数第 n 个结点，并且返回链表的头结点。
 */
public class Solution {
    /**迭代，即双指针**/
    public ListNode removeNthFromEnd(ListNode head, int n) {
        ListNode dummy = new ListNode(0, head);
        ListNode left = dummy, right = dummy;
        //  先让快指针领先慢指针n个节点，然后共同移动直至快节点到末尾，
        //  此时left.next就是倒数的第n个节点
        while (n-- > 0) {
            right = right.next;
        }
        while (right.next != null) {
            left = left.next;
            right = right.next;
        }
        left.next = left.next.next;
        return dummy.next;
    }
    /***递归，天然优势就是从后往前归***/

    int count;
    public ListNode removeNthFromEnd2(ListNode head, int n) {
        return traverse(head, n);
    }

    private ListNode traverse(ListNode head, int n) {
        if (head == null) {
            return null;
        }
        head.next = traverse(head.next, n);
        count++;
        if (count == n) {
            return head.next;
        } else {
            return head;
        }
    }
}
