package LC24;

/*
给你一个链表，两两交换其中相邻的节点，并返回交换后链表的头节点。
你必须在不修改节点内部的值的情况下完成本题（即，只能进行节点交换）。
 */
public class Solution {
    public ListNode swapPairs(ListNode head) {
        ListNode dummy = new ListNode(0, head);
        ListNode cur = dummy;
        // cur指向要交换的节点的前一个节点
        while (cur.next != null && cur.next.next != null) {
            ListNode third = cur.next.next.next;
            ListNode second = cur.next.next;
            ListNode first = cur.next;
            cur.next = second;
            second.next = first;
            first.next = third;

            cur = cur.next.next;
        }
        return dummy.next;
    }

    /************递归**************/
    public ListNode swapPairs2(ListNode head) {
        return traverse(head);
    }

    private ListNode traverse(ListNode head) {
        if (head == null || head.next == null) {
            return head;
        }
        ListNode temp = head.next;
        // 这是错误的顺序，因为 temp.next = head之后，temp和head是互相指向的，此时下一行就是死循环了
//        temp.next = head;
//        head.next = traverse(temp.next);
        head.next = traverse(temp.next);
        temp.next = head;
        return temp;

    }
}
