package test;
public class Main {
    static int count = 0;
    static String s = "123456789";
    public static void main(String[] args) {
        int[] nums = new int[]{1,2,3,4,5,6,7,8,9};

        backtracking(nums, 100, 0, 0);
        System.out.println(count);
    }

    public static void backtracking(int[] nums, int target, int index, int sum) {
        if (index == nums.length) {
            if (sum == target) {
                count++;
            }
        } else {
            for (int i = index; i < nums.length; i++) {
//                backtracking(nums, target, index + 1, sum + nums[index]);
//                backtracking(nums, target, index + 1, sum - nums[index]);
                backtracking(nums, target, i + 1, sum + Integer.parseInt(s.substring(index, i+ 1)));
                backtracking(nums, target, i + 1, sum - Integer.parseInt(s.substring(index, i+ 1)));

            }
        }
    }
}
