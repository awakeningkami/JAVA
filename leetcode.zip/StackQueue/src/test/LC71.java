package test;
import java.util.*;
public class LC71 {
    public String simplifyPath(String path) {
        Deque<String> deque = new LinkedList<>();
        String[] p = path.split("/");
        for (String s : p) {
            if ("..".equals(s)) {
                deque.pollLast();
            } else if (s.length() == 0 || ".".equals(s)) {
            } else {
                deque.offerLast(s);
            }
        }

        StringBuilder sb = new StringBuilder();
        while (!deque.isEmpty()) {
            sb.append("/").append(deque.pollFirst());
        }
        return sb.length() == 0 ? "/" : sb.toString();
    }
}
