package LC239;

import java.util.Deque;
import java.util.LinkedList;

/*滑动窗口最大值
给你一个整数数组 nums，有一个大小为 k 的滑动窗口从数组的最左侧移动到数组的最右侧。
你只可以看到在滑动窗口内的 k 个数字。滑动窗口每次只向右移动一位。
返回 滑动窗口中的最大值 。
 */
/*
单调队列，保证队列元素是从大到小的顺序，那么最大值就是队头。
每个元素只入队和出队一次，那么总复杂度为 O(n)。
队列中维护的是index，方便控制窗口长度
 */
public class Solution {
    public int[] maxSlidingWindow(int[] nums, int k) {
        // 双端队列
        Deque<Integer> deque = new LinkedList<>();
        int[] res = new int[nums.length - k + 1];
        for (int i = 0; i < nums.length; i++) {
            // 1.保证窗口的长度。 queue.peekFirst()是窗口最左边的index
            // 如果达到窗口长度(是有序的)，那么先腾出一个位置，因为窗口要移动了
            if (!deque.isEmpty() && deque.peekFirst() < i - k + 1) {    // 需判断!queue.isEmpty()，是因为防止queue.peek()空指针
                deque.pollFirst();
            }
            // 2.入队前，先把小于的全部出队，从队尾出队
            while (!deque.isEmpty() && nums[i] >= nums[deque.peekLast()]) {
                deque.pollLast();
            }
            // 3.入队
            deque.offer(i);
            // 4.保存结果
            if (i - k + 1 >= 0) {
                res[i - k + 1] = nums[deque.peekFirst()];
            }
        }
        return res;
    }

    public static void main(String[] args) {
        int[] nums = new int[]{1,3,-1,-3,5,3,6,7};
        int k = 3;
        Solution solution = new Solution();
        solution.maxSlidingWindow(nums, k);
        System.out.println();
    }
}
