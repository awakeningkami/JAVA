package LC347;

import java.util.*;

/*前 K 个高频元素
给你一个整数数组 nums 和一个整数 k ，请你返回其中出现频率前 k 高的元素。你可以按 任意顺序 返回答案。
输入: nums = [1,1,1,2,2,3], k = 2
输出: [1,2]
 */
/*
优先队列：PriorityQueue，因为没必要全部排序，只需要top K就行
 */
public class Solution {
    public int[] topKFrequent(int[] nums, int k) {
        HashMap<Integer, Integer> map = new HashMap<>();
        int[] res = new int[k];
        for (int num : nums) {
            map.put(num, map.getOrDefault(num, 0) + 1);
        }
        PriorityQueue<Map.Entry<Integer, Integer>> queue = new PriorityQueue<>(
                (e1, e2) -> e2.getValue() - e1.getValue());
        queue.addAll(map.entrySet());
        for (int i = 0; i < k;i++) {
            res[i] = queue.poll().getKey();
        }
        return res;
    }

}
