package LC1047;

import java.util.LinkedList;

/*删除字符串中的所有相邻重复项
给出由小写字母组成的字符串 S，重复项删除操作会选择两个相邻且相同的字母，并删除它们。
在 S 上反复执行重复项删除操作，直到无法继续删除。
在完成所有重复项删除操作后返回最终的字符串。答案保证唯一。
输入："abbaca"
输出："ca"
解释：
例如，在 "abbaca" 中，我们可以删除 "bb" 由于两字母相邻且相同，这是此时唯一可以执行删除操作的重复项。
之后我们得到字符串 "aaca"，其中又只有 "aa" 可以执行重复项删除操作，所以最后的字符串为 "ca"。
 */
public class Solution {
    public String removeDuplicates(String s) {
        LinkedList<Character> stack = new LinkedList<>();
        for (int i = 0; i < s.length(); i++) {
            if (!stack.isEmpty() && stack.peek() == s.charAt(i)) {
                stack.pop();
            } else {
                stack.push(s.charAt(i));
            }
        }
        char[] arr = new char[stack.size()];
        for (int i = arr.length - 1; i >= 0; i--) {
            arr[i] = stack.pop();
        }
        // toString() 尽量不要用，因为不知道是怎么重写的
        // StringBuffer和StringBuilder的toString() 是返回String
        return new String(arr);
    }

    // 字符串当做栈
    /*
    API: sb.deleteCharAt(int index)
         sb.delete(int start, int end)
     */
    public String removeDuplicates2(String s) {
        StringBuilder sb = new StringBuilder();
        int curIndex = -1;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (curIndex >= 0 && sb.charAt(curIndex) == c) {
                sb.deleteCharAt(curIndex);
                curIndex--;
            } else {
                sb.append(c);
                curIndex++;
            }
        }
        return sb.toString();
    }

    /**上述方法都需要删除元素，直接覆盖更加快**/
    // 双指针
    /*
    API: new String(char[], offset, count)
     */
    public String removeDuplicates3(String s) {
        char[] arr = s.toCharArray();
        int slow = -1;
        for (int fast = 0; fast < arr.length; fast++) {
            if (slow >= 0 && arr[slow] == arr[fast]) {
                slow--;
            } else {
                arr[++slow] = arr[fast];
            }
        }
        return new String(arr, 0, slow + 1);
    }

    public static void main(String[] args) {
        Solution solution = new Solution();
        solution.removeDuplicates3("abbaca");
        System.out.println();

    }
}
