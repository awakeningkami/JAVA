package offer56I;

/*数组中数字出现的次数
一个整型数组 nums 里除两个数字之外，其他数字都出现了两次。请写程序找出这两个只出现一次的数字。
要求时间复杂度是O(n)，空间复杂度是O(1)。
 */
/*
两个相同数字异或为 0； 0和任何数异或都为该数；异或运算满足交换律, 即运算结果与元素顺序无关。
1. 数组中存在1个数字不重复的情况时(x)，将所有的数字异或即可得到x
2. 数组中存在2个数字不重复的情况时(x,y)，将所有的数字异或即得到x异或y，办法把问题简化为1：
    分组：保证相同的数字分到一组即可，同时还要把x和y分开，然后通过1即可得到x和y
    因为x和y不等，那么他们的二进制总有一位不同，所以异或结果总有一位为1，根据这一位就可以把x y分到不同的组
 */
public class Solution {
    public int[] singleNumbers(int[] nums) {
        //用于将所有的数异或起来
        int x = 0;
        for (int num : nums) {
            x ^= num;
        }
        //获得x中最低位的1
        int mask = 1;
        while ((x & mask) == 0) {
            mask = mask << 1;
        }

        int a = 0, b = 0;
        for (int num : nums) {
            if ((num & mask) == 0) {
                a ^= num;
            } else {
                b ^= num;
            }
        }
        return new int[]{a, b};

    }
}
