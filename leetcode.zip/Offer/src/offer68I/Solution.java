package offer68I;

/*二叉搜索树的最近公共祖先

 */
public class Solution {
    public TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
        return dfs(root, p, q);
    }

    public TreeNode dfs(TreeNode root, TreeNode p, TreeNode q) {
        if (root.val > p.val && root.val > q.val) {
            return dfs(root.left, p, q);
        } else if (root.val < p.val && root.val < q.val) {
            return dfs(root.right, p, q);
        } else {
            return root;
        }
    }
}
