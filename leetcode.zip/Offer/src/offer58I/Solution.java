package offer58I;

import java.lang.reflect.Array;
import java.util.Arrays;

/*翻转单词顺序
输入一个英文句子，翻转句子中单词的顺序，但单词内字符的顺序不变。
为简单起见，标点符号和普通字母一样处理。例如输入字符串"I am a student. "，则输出"student. a am I"。
 */
public class Solution {
    public String reverseWords(String s) {
        char[] arr = s.toCharArray();
        StringBuilder sb = new StringBuilder();
        int right = arr.length - 1;
        for (int left = arr.length - 1; left >= 0; left--) {
            if (arr[left] == ' ') {
                continue;
            }
            right = left;
            while (left >= 0 && arr[left] != ' ') {
                left--;
            }
            sb.append(s, left + 1, right + 1).append(' ');
        }
        if (sb.length() == 0) {
            return "";
        }
        sb.deleteCharAt(sb.length() - 1);
        return sb.toString();
    }
}
