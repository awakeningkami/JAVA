package offer68II;
/*二叉树的最近公共祖先
给定一个二叉树, 找到该树中两个指定节点的最近公共祖先。
百度百科中最近公共祖先的定义为：“对于有根树 T 的两个结点 p、q，
最近公共祖先表示为一个结点 x，满足 x 是 p、q 的祖先且 x 的深度尽可能大（一个节点也可以是它自己的祖先）。”
 */
public class Solution {
    public TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
        return postDFS(root, p, q);
    }

    public TreeNode postDFS(TreeNode root, TreeNode p, TreeNode q) {
        // 碰到 p或者q就返回，因为祖先只能在上面
        if (root == null || root.val == p.val || root.val == q.val) {
            return root;
        }
        TreeNode left = postDFS(root.left, p, q);
        TreeNode right = postDFS(root.right, p, q);
        if (left == null) {// 左子树没p or q
            return right;
        } else if (right == null) { // 右子树没p or q
            return left;
        } else {    // p q分别分布在左右子树中
            return root;
        }
    }
}
