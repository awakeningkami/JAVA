package offer61;

/*扑克牌中的顺子
从若干副扑克牌中随机抽 5 张牌，判断是不是一个顺子，即这5张牌是不是连续的。
2～10为数字本身，A为1，J为11，Q为12，K为13，而大、小王为 0 ，可以看成任意数字。A 不能视为 14。
 */

import java.util.Arrays;

/*
1. 如果有重复一定不为顺子,直接返回false
2. 在没有重复的前提下, 数组的最大值和最小值之差如果小于4即可 (除了大小王0).
 */
public class Solution {
    public boolean isStraight(int[] nums) {
        Arrays.sort(nums);
        int index = 0;
        for (int i = 0; i < 4; i++) {
            if (nums[i] == 0) {
                index++;
            } else {
                if (nums[i] == nums[i + 1]) {
                    return false;
                }
            }
        }
        return nums[4] - nums[index] < 5;
    }
}
