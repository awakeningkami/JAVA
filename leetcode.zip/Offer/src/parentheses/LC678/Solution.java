package parentheses.LC678;

/*有效的括号字符串
给定一个只包含三种字符的字符串：（ ，） 和 *，写一个函数来检验这个字符串是否为有效字符串。有效字符串具有如下规则：

任何左括号 ( 必须有相应的右括号 )。
任何右括号 ) 必须有相应的左括号 ( 。
左括号 ( 必须在对应的右括号之前 )。
* 可以被视为单个右括号 ) ，或单个左括号 ( ，或一个空字符串。
一个空字符串也被视为有效字符串。
 */

import java.util.LinkedList;

/*
括号匹配的问题可以用栈求解。
如果字符串中没有星号，则只需要一个栈存储左括号，在从左到右遍历字符串的过程中检查括号是否匹配。
在有星号的情况下，需要两个栈分别存储左括号和星号。从左到右遍历字符串,优先匹配左括号；再用 * 匹配剩余的 (
 */
public class Solution {
    public boolean checkValidString(String s) {
        LinkedList<Integer> stack1 = new LinkedList<>();
        LinkedList<Integer> stack2 = new LinkedList<>();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(') {
                stack1.push(i);
            } else if (c == '*') {
                stack2.push(i);
            } else {
                if (!stack1.isEmpty()) {
                    stack1.pop();
                } else if (!stack2.isEmpty()) {
                    stack2.pop();
                } else {
                    return false;
                }
            }
        }

        while (!stack1.isEmpty() && !stack2.isEmpty()) {
            // 下面的方法会超时，因为死循环
//            if (stack1.peek() < stack2.peek()) {
//                stack1.pop();
//                stack2.pop();
//            }

            if (stack1.pop() > stack2.pop()) {
                return false;
            }
        }
        return stack1.isEmpty();
    }
}
