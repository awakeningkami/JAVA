package parentheses.LC301;

/*删除无效的括号
给你一个由若干括号和字母组成的字符串 s ，删除最小数量的无效括号，使得输入的字符串有效。
返回所有可能的结果。答案可以按 任意顺序 返回。
 */

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/*
所有可能就用回溯，要删除的括号回溯，要删除几个那么就dfs就是几层，然后判断括号是否合法就ok
 */
public class Solution {
    List<String> res = new ArrayList<>();
    public List<String> removeInvalidParentheses(String s) {
        int left = 0, right = 0;
        for (char c : s.toCharArray()) {
            // 这里的计算顺序一定不能反，因为右括号要和左括号匹配，所以必须先计算左括号
            // 最后的 left和right是必须要删除的个数
            if (c == '(') {
                left++;
            }
            if (c == ')') {
                if (left > 0) {
                    left--;
                } else {
                    right++;
                }
            }

        }
        backtracking(left, right, s, 0);
        return res;
    }
    // 回溯，移除括号
    public void backtracking(int left, int right, String s, int index) {

        if (left == 0 && right == 0) {
            if (isValid(s)) {
                res.add(s);
            }
            return;
        }
        for (int i = index; i < s.length(); i++) {
            if (i > index && s.charAt(i) == s.charAt(i - 1)) {  // 树层去重
                continue;
            }
            if (s.charAt(i) == '(' && left > 0) {
                // 因为删除括号后，后面的会向前补齐，所以index=i
                // left 和 s 都是自动回溯(s是新字符串)
                backtracking(left - 1, right, s.substring(0, i) + s.substring(i + 1), i);
            }
            if (s.charAt(i) == ')' && right > 0) {
                backtracking(left, right - 1, s.substring(0, i) + s.substring(i + 1), i);
            }
        }
    }

    // 判定是否有效
    boolean isValid(String s) {
        LinkedList<Character> stack = new LinkedList<>();
        for (char c : s.toCharArray()) {
            if (c == '(') {
                stack.push('(');
            }
            if (c == ')') {
                if (stack.isEmpty()) {
                    return false;
                } else {
                    stack.pop();
                }
            }
        }
        return stack.isEmpty();
    }

    public static void main(String[] args) {
        String s = "))()(";
        Solution solution = new Solution();
        List<String> strings = solution.removeInvalidParentheses(s);
        for (String aa : strings) {
            System.out.println(aa);
        }

    }

}
