package parentheses.LC32;

import java.util.LinkedList;

/*最长有效括号
给你一个只包含 '(' 和 ')' 的字符串，找出最长有效（格式正确且连续）括号子串的长度。
 */
/*
两种索引会入栈
1. 等待被匹配的左括号索引。
2. 充当「参照物」的右括号索引。因为：当左括号匹配光时，栈需要留一个垫底的参照物，用于计算一段连续的有效长度。
 */
class Solution {
    public int longestValidParentheses(String s) {
        LinkedList<Integer> stack = new LinkedList<>();
        int res = 0;
        stack.push(-1);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            // 遇到'('直接入栈
            if (c == '(') {
                stack.push(i);
            } else {
                // 遇到')'先出栈抵消左括号
                stack.pop();
                // 若栈为空说明右括号冗余
                if (stack.isEmpty()) {
                    // 冗余的右括号充当下一个-1
                    stack.push(i);
                } else {
                    // 若栈不为空说明匹配到有效的括号序列,更新即可
                    res = Math.max(res, i - stack.peek());
                }
            }
        }
        return res;
    }
}
