package offer56II;

/*数组中数字出现的次数 II
在一个数组 nums 中除一个数字只出现一次之外，其他数字都出现了三次。请找出那个只出现一次的数字。
 */
/*
如果一个数字出现3次，它的二进制每一位也出现的3次。
 */
public class Solution {
    public int singleNumber(int[] nums) {
        int[] bits = new int[32];
        for (int num : nums) {
            int j = 0;
            while (num != 0) {
                bits[j] += num % 2;
                num /= 2;
                j++;
            }
        }
        int res = 0;
        for (int i = 0; i < 32; i++) {
            res += (1 << i) * (bits[i] % 3);
        }
        return res;
    }

    public static void main(String[] args) {
        int[] ints = {4, 5, 4, 4,};
        Solution solution = new Solution();
        int i = solution.singleNumber(ints);
        System.out.println(i);
    }
}
