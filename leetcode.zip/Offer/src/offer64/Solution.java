package offer64;
/*
求 1+2+...+n ，要求不能使用乘除法、for、while、if、else、switch、case等关键字及条件判断语句（A?B:C）。
 */
/*
精髓就是，通过递归替代循环。通过短路运算符来替代条件判断。
if(A && B)  // 若 A 为 false ，则 B 的判断不会执行（即短路），直接判定 A && B 为 false
if(A || B) // 若 A 为 true ，则 B 的判断不会执行（即短路），直接判定 A || B 为 true
 */
public class Solution {
    int res = 0;
    public int sumNums(int n) {
        boolean flag = n > 1 && sumNums(n - 1) > 0;
        res += n;
        return res;
    }
}
