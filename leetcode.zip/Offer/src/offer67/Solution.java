package offer67;

/*把字符串转换成整数

 */
public class Solution {
    public int strToInt(String str) {
        char[] arr = str.trim().toCharArray();
        if (arr.length == 0) {
            return 0;
        }
        int flag = 1;
        int index = 0;
        if (arr[index] == '-') {
            flag = -1;
            index++;
        } else if (arr[index] == '+') {
            index++;
        }
        int res = 0;
        for (int i = index; i < arr.length; i++) {
            if (arr[i] < '0' || arr[i] > '9') {
                break;
            }
            if (res > Integer.MAX_VALUE / 10 || (res == Integer.MAX_VALUE / 10 && Integer.MAX_VALUE % 10 < arr[i] - '0')){
                return Integer.MAX_VALUE;
            }
            if (res < Integer.MIN_VALUE / 10 || (res == Integer.MIN_VALUE /10 && -(Integer.MIN_VALUE % 10) < arr[i] - '0')) {
                return Integer.MIN_VALUE;
            }

            res = res * 10 + flag * (arr[i] - '0');
        }
        return res;
    }
}
