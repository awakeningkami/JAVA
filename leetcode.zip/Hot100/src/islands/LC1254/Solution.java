package islands.LC1254;

/*
二维矩阵 grid 由 0 （土地）和 1 （水）组成。
岛是由最大的4个方向连通的 0 组成的群，封闭岛是一个 完全 由1包围（左、上、右、下）的岛。
请返回 封闭岛屿 的数目。
 */
/*
题目有两点不同：
1. 用 0 表示陆地，用 1 表示海水
2. 所谓封闭岛屿就是上下左右全部被 1 包围的 0，也就是说靠边的陆地不算作封闭岛屿
参考LC200题，把那些靠边的岛屿排除掉，剩下的就是封闭岛屿
*/
public class Solution {
    public int closedIsland(int[][] grid) {
        int m = grid.length, n = grid[0].length;
        for (int i = 0; i < m; i++) {
            // 把靠上边的岛屿修改为2
            dfs(grid, i, 0);
            // 把靠下边的岛屿修改为2
            dfs(grid, i, n - 1);
        }
        for (int j = 0; j < n; j++) {
            // 把靠左边的岛屿修改为2
            dfs(grid, 0, j);
            // 把靠右边的岛屿修改为2
            dfs(grid, m - 1, j);
        }

        int res = 0;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (grid[i][j] == 0) {
                    dfs(grid, i, j);
                    res++;
                }
            }
        }
        return res;
    }

    public void dfs(int[][] grid, int i, int j) {
        int m = grid.length, n = grid[0].length;
        if (i < 0 || j < 0 || i >= m || j >= n) {
            return;
        }
        if (grid[i][j] != 0) {
            return;
        }
        grid[i][j] = 2;
        dfs(grid, i - 1, j);
        dfs(grid, i + 1, j);
        dfs(grid, i, j - 1);
        dfs(grid, i, j + 1);
    }
}
