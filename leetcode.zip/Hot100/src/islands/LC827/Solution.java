package islands.LC827;

import java.util.HashMap;
import java.util.HashSet;

/* 最大人工岛
给你一个大小为 n x n 二进制矩阵 grid 。最多 只能将一格 0 变成 1 。
返回执行此操作后，grid 中最大的岛屿面积是多少？
岛屿 由一组上、下、左、右四个方向相连的 1 形成。
 */
/*
初步想法：先计算出所有岛屿的面积，在所有的格子上标记出岛屿的面积。然后搜索哪个海洋格子相邻的两个岛屿面积最大。
    比较难实现，而且存在问题（假如海洋格子相邻的岛屿来自同一个）
正确解法：对岛屿编号，另外用一个数组记录每个岛屿的面积
 */
public class Solution {
    public int largestIsland(int[][] grid) {
        HashMap<Integer, Integer> map = new HashMap<>();
        map.put(0, 0);  // 海的面积记录为0
        int res = 0;
        int index = 2;
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                if (grid[i][j] == 1) {
                    int area = dfs(grid, i, j, index);
                    map.put(index, area);
                    index++;
                }
            }
        }

        // 把一个海洋变成陆地
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                if (grid[i][j] == 0) {
                    HashSet<Integer> set = new HashSet<>(); // 防止是同一个岛屿
                    int area = 1;
                    if (isValid(grid, i - 1, j)) {
                        set.add(grid[i - 1][j]);
                    }
                    if (isValid(grid, i + 1, j)) {
                        set.add(grid[i + 1][j]);
                    }
                    if (isValid(grid, i, j - 1)) {
                        set.add(grid[i][j - 1]);
                    }
                    if (isValid(grid, i, j + 1)) {
                        set.add(grid[i][j + 1]);
                    }
                    for (int num : set) {
                        area += map.get(num);
                    }
                    res = Math.max(res, area);
                }
            }
        }
        // 没有海洋的话进入不了判断，那么res此时还是为0
        return res == 0 ? grid.length * grid[0].length : res;
    }

    // 找岛屿并标号
    public int dfs(int[][] grid, int i, int j, int index) {

        if (!isValid(grid, i, j)) {
            return 0;
        }
        if (grid[i][j] != 1) {
            return 0;
        }
        grid[i][j] = index;
        return 1 + dfs(grid, i - 1, j, index) +
                dfs(grid, i + 1, j, index) +
                dfs(grid, i, j - 1, index) +
                dfs(grid, i, j + 1, index);
    }

    public boolean isValid(int[][] grid,int i, int j) {
        int m = grid.length, n = grid[0].length;
        if (i >= 0 && j >= 0 && i < m && j < n) {
            return true;
        }
        return false;
    }
}
