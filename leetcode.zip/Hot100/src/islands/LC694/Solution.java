package islands.LC694;
/* 不同的岛屿数量
输入一个二维矩阵，0 表示海水，1 表示陆地，计算不同的岛屿数量
 */

import java.util.HashSet;

/*
// https://labuladong.github.io/algo/4/31/108/
1. 很显然我们得想办法把二维矩阵中的岛屿进行转化，变成比如字符串这样的类型 (序列化)，
    然后利用 HashSet 这样的数据结构去重，最终得到不同的岛屿的个数。
2. 对于形状相同的岛屿，如果从同一起点出发，dfs 函数遍历的顺序肯定是一样的，
    因为遍历顺序是写死在你的递归函数里面的，不会动态改变。
3. 假设它们的遍历顺序是：
        下，右，上，撤销上，撤销右，撤销下
    如果分别用 1, 2, 3, 4 代表上下左右，用 -1, -2, -3, -4 代表上下左右的撤销，那么可以这样表示它们的遍历顺序：
        2, 4, 1, -1, -4, -2
    这就相当于是岛屿序列化的结果，只要每次使用 dfs 遍历岛屿的时候生成这串数字进行比较，就可以计算到底有多少个不同的岛屿了。
4.
PS：为什么记录撤销操作才能唯一表示遍历顺序呢？不记录撤销操作好像也可以？
比方说「下，右，撤销右，撤销下」和「下，撤销下，右，撤销右」显然是两个不同的遍历顺序，
但如果不记录撤销操作，那么它俩都是「下，右」，成了相同的遍历顺序，显然是不对的。
 */
public class Solution {
    int numDistinctIslands(int[][] grid) {
        int m = grid.length, n = grid[0].length;
        // 记录所有岛屿的序列化结果
        HashSet<String> set = new HashSet<>();
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (grid[i][j] == 1) {
                    StringBuilder sb = new StringBuilder();
                    dfs(grid, i, j, sb, 0);
                    set.add(sb.toString());
                    System.out.println(sb.toString());
                }
            }
        }
        return set.size();
    }

    public void dfs(int[][] grid, int i, int j, StringBuilder sb, int dir) {
        int m = grid.length, n = grid[0].length;
        if (i < 0 || j < 0 || i >= m || j >= n) {
            return;
        }
        if (grid[i][j] != 1) {
            return;
        }

        // 前序遍历位置：进入 (i, j)
        grid[i][j] = 2;
        sb.append(dir).append(",");
        dfs(grid, i - 1, j, sb, 1); // 上
        dfs(grid, i + 1, j, sb, 2); // 下
        dfs(grid, i, j - 1, sb, 3); // 左
        dfs(grid, i, j + 1, sb, 4); // 右

        // 后序遍历位置：离开 (i, j)
        sb.append(-dir).append(",");
    }

    public static void main(String[] args) {
        int[][] grid = new int[][] {
                {1,1,0,0,0,},
                {1,0,0,0,0,},
                {0,0,0,1,0,},
                {0,0,0,1,1,}
        };
        Solution solution = new Solution();
        solution.numDistinctIslands(grid);
    }

}
