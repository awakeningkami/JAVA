package islands.basic;

// https://leetcode.cn/problems/number-of-islands/solution/dao-yu-lei-wen-ti-de-tong-yong-jie-fa-dfs-bian-li-/
public class Solution {
    /*
    那么如何在二维矩阵中使用 DFS 搜索呢？
    把二维矩阵中的每一个位置看做一个节点，这个节点的上下左右四个位置就是相邻节点，
    那么整个矩阵就可以抽象成一幅网状的「图」结构。
    因为二维矩阵本质上是一幅「图」，所以遍历的过程中需要一个 visited 布尔数组防止走回头路（也可以不用，改变grid的数值以此来判断遍历过）
    为了更好地区分，采用统一格式：0-海 1-陆地 2-访问过的陆地
     */
    // 二维矩阵遍历框架
    void dfsUniversal(int[][] grid, int i, int j, boolean[][] visited) {
        int m = grid.length, n = grid[0].length;
        if (i < 0 || j < 0 || i >= m || j >= n) {
            return;
        }
        if (visited[i][j]) {
            return;
        }
        visited[i][j] = true;
        dfsUniversal(grid, i - 1, j, visited);
        dfsUniversal(grid, i + 1, j, visited);
        dfsUniversal(grid, i, j - 1, visited);
        dfsUniversal(grid, i, j + 1, visited);
    }

    void dfs(int[][] grid, int i, int j) {
        // 判断 base case
        int m = grid.length, n = grid[0].length;
        if (i < 0 || j < 0 || i >= m || j >= n) {
            return;
        }
        // 如果这个格子不是陆地，直接返回
        if (grid[i][j] != 1) {
            return;
        }
        grid[i][j] = 2; // 将格子标记为「已遍历过」
        dfs(grid, i - 1, j);
        dfs(grid, i + 1, j);
        dfs(grid, i, j - 1);
        dfs(grid, i, j + 1);
    }

    public void fun(int[][] grid) {
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                /*
                处理逻辑
                if (grid[i][j] == '1') {
                    dfs(grid, i, j);
                }
                 */
            }
        }
    }
}
