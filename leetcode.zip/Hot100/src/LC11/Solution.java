package LC11;

/* 盛最多水的容器
给定一个长度为 n 的整数数组 height 。有 n 条垂线，第 i 条线的两个端点是 (i, 0) 和 (i, height[i]) 。
找出其中的两条线，使得它们与 x 轴共同构成的容器可以容纳最多的水。
返回容器可以储存的最大水量。
 */
/*
双指针
柱子是最两侧的柱子时，水的宽度最大，若此时高度也最高就ok了。
我们在移动左指针或者右指针的时候，宽度一定减小，如果想让面积增大，只有让高度增加。
移动长柱子，高度一定不会增加；移动短柱子，高度可能增加，此时面积也可能变大。
 */
public class Solution {
    public int maxArea(int[] height) {
        int left = 0, right = height.length - 1;
        int res = 0;
        while (left < right) {
            res = Math.max(res, Math.min(height[left], height[right]) * (right - left + 1));
            if (height[left] < height[right]) {
                left++;
            } else {
                right--;
            }
        }
        return res;
    }
}
