package LC3;

import java.util.HashMap;

/* 3. 无重复字符的最长子串
给定一个字符串 s ，请你找出其中不含有重复字符的 最长子串 的长度。
 */
/*
滑动窗口（双指针）
用map记录当前子串已经存在的元素，如果当前字符已经存在，那么直接移动左指针跳过该字符，
    并且要从map中删除当前子串中已经不存在的字符（这很难实现，换个思路）
    1. 如果当前字符在当前子串中存在，左指针直接跳到这个字符的下一位
    2.                       不存在，那么我们就不需要动左指针
    去最大值即可处理上述两种情况，主要是防止左指针前移
 */
public class Solution {
    public int lengthOfLongestSubstring(String s) {
        int left = 0;
        int res = 0;
        HashMap<Character, Integer> map = new HashMap<>();
        for (int right = 0; right < s.length(); right++) {
            char c = s.charAt(right);
            if (map.containsKey(c)) {
                left = Math.max(left, map.get(c) + 1);
            }
            map.put(s.charAt(right), right);
            res = Math.max(res, right - left + 1);
        }
        return res;
    }
}
