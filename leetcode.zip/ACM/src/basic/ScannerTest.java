package basic;


import java.util.Scanner;

public class ScannerTest {
    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        int i = sc.nextInt();  // 读数值，以空格结束
//        System.out.println("i = " + i);
//        System.out.printf("%b", true);  // 输出boolean类型

        Scanner scanner = new Scanner(System.in);
        String next = scanner.next();   // 读字符串，以空格结束
        System.out.println("next = " + next);
        String nextLine = scanner.nextLine();
        System.out.println("next = " + nextLine); // 读全部
    }
}
