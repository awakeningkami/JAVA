package test;

import java.util.Scanner;
/*
输入包括两个正整数a,b(1 <= a, b <= 1000),输入数据包括多组。
输出a+b的结果

 */
public class Test1 {
    public static void main(String[] args) {
        System.out.println(3/2);
    }
}
