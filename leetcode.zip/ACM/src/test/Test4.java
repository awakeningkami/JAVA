package test;

import java.util.Arrays;
import java.util.Scanner;

/*
输入数据有多组, 每行表示一组输入数据。
每行不定有n个整数，空格隔开。(1 <= n <= 100)。
每组数据输出求和的结果
 */
public class Test4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] s = scanner.nextLine().split(" ");
        System.out.println(Arrays.toString(s));
    }
}
