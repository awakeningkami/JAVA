package LC28;

import java.util.Arrays;

/*实现 strStr()
实现 strStr() 函数。
给你两个字符串 haystack 和 needle ，请你在 haystack 字符串中找出 needle 字符串出现的第一个位置（下标从 0 开始）。
如果不存在，则返回  -1 。

说明：
当 needle 是空字符串时，我们应当返回什么值呢？这是一个在面试中很好的问题。
对于本题而言，当 needle 是空字符串时我们应当返回 0 。
 */
/*
KMP算法
 */
public class Solution {
    public int strStr(String haystack, String needle) {
        if ("".equals(needle)) {
            return 0;
        }
        char[] s = haystack.toCharArray();
        char[] p = needle.toCharArray();
        int[] next = buildNext(p);
        int indexS = 0, indexP = 0;
        while (indexS < s.length) {
            if (s[indexS] == p[indexP]) {
                indexS++;
                indexP++;
            } else if (indexP != 0) {
                indexP = next[indexP - 1];
            } else {
                indexS++;
            }
            if (indexP == p.length) {
                return indexS - indexP;
            }
        }
        return -1;
    }

    private int[] buildNext(char[] p) {
        int[] next = new int[p.length];
        int i = 1;
        int now = 0; // now: next[i-1]
        while (i < p.length) {
            if (p[now] == p[i]) {
                now++;
                next[i] = now;
                i++;
            } else if (now != 0) {
                now = next[now - 1];
            } else {
                next[i] = now;
                i++;
            }
        }
        return next;
    }

    public static void main(String[] args) {
        String s = "";
        System.out.println(s.toCharArray());
    }
}
