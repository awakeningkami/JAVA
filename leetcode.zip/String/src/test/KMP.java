package test;

public class KMP {
    char[] s = new char[]{'a', 'b', 'c', 'a', 'b', 'd'};
    char[] p = new char[]{'a', 'b'};
    // next[x]: P[0]~P[x] 这一段字符串，使得k-前缀恰等于k-后缀的最大的k.(除了字符串本身)
    int[] next = new int[p.length];

    private void buildNext() {
        int i = 1;
        int now = 0;
        while (i < p.length) {
            if (p[now] == p[i]) {
                now++;
                next[i] = now;
                i++;
            } else if (now != 0) {
                now = next[now - 1];
            } else {
                next[i] = now;
                i++;
            }
        }
    }

    private void search() {
        int tar = 0, pos = 0;
        while (tar < s.length) {
            if (s[tar] == p[pos]) {
                tar++;
                pos++;
            } else if (pos != 0) {
                pos = next[pos - 1];
            } else {
                tar++;
            }
            if (pos == p.length) {
                System.out.println(tar - pos);
                pos = next[pos - 1];
            }
        }
    }
}
