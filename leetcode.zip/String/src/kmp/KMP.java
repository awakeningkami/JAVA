package kmp;

import java.util.Arrays;

/*
https://www.zhihu.com/question/21923021/answer/1032665486
 */
public class KMP {
    char[] s = new char[]{'a', 'b', 'c', 'a', 'b', 'd'};
    char[] p = new char[]{'a', 'b'};
    // next[x]: P[0]~P[x] 这一段字符串，使得k-前缀恰等于k-后缀的最大的k.(除了字符串本身)
    int[] next = new int[p.length];


    public void search() {
        int tar = 0; // 主串s将要匹配的位置
        int pos = 0; // 模式串p将要匹配的位置
        while (tar < s.length) {
            if (s[tar] == p[pos]) { // 两个字符相等，则tar和pos各进一步
                tar++;
                pos++;
            } else if (pos != 0) { // 失配了，若pos!=0, 则依据next数组移动标尺
                pos = next[pos - 1];
            } else {    // 直接把标尺右移一位
                tar++;
            }
            if (pos == p.length) {
                System.out.println(tar - pos);
                pos = next[pos - 1];
            }
        }
    }

    public void buildNext() {
        int i = 1;
        int now = 0;    // now: next[i-1]
        while (i < next.length) {
            if (p[now] == p[i]) {  // p[now] == p[i],则可以向右扩展一位
                now++;
                next[i] = now;
                i++;
            } else if(now != 0) {   // 缩小now
                now = next[now - 1];
            } else {    // now已经为0了，不能在缩小了
                next[i] = now;
                i++;
            }
        }
    }

    public static void main(String[] args) {
        KMP kmp = new KMP();
        kmp.buildNext();
        kmp.search();
    }
}
