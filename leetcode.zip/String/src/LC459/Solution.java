package LC459;

import java.util.Arrays;

/* 重复的子字符串
给定一个非空的字符串 s ，检查是否可以通过由它的一个子串重复多次构成。
 */
/*
在一个串中查找是否出现过另一个串，这是KMP的看家本领。
KMP中的next数组记录的是最长相同前后缀，用next即可完成此题
 */
public class Solution {
    public boolean repeatedSubstringPattern(String s) {
        char[] arr = s.toCharArray();
        int[] next = buildNext(arr);
        System.out.println(Arrays.toString(next));
        int len = s.length();
        int maxPrefix = next[arr.length - 1];
        // 假设字符串s使用多个重复子串构成（这个子串是最小重复单位），那么 len-maxPrefix 一定是那个子串
        // 用 len % (len - maxPrefix) == 0来判断，加 maxPrefix != 0 是因为出去子串为字符串s本身，而此时maxPrefix=0
        if (maxPrefix != 0 && len % (len - maxPrefix) == 0) {
            return true;
        }
        return false;
    }

    public int[] buildNext(char[] p) {
        int[] next = new int[p.length];
        int i = 1;
        int now = 0; // 记录next[i - 1];
        while (i < p.length) {
            if (p[now] == p[i]) {
                now++;
                next[i] = now;
                i++;
            } else if (now != 0) {
                now = next[now - 1];
            } else {
                next[i] = now;
                i++;
            }
        }
        return next;
    }

    public static void main(String[] args) {
        Solution solution = new Solution();
        String s = "a";
        boolean b = solution.repeatedSubstringPattern(s);
        System.out.println(b);
    }
}
